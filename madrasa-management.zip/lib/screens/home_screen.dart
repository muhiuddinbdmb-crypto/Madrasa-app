import 'package:flutter/material.dart';
import 'admin_approval_screen.dart';

class HomeScreen extends StatelessWidget {
  final String userName;
  final String userRole;
  final bool isMainAdmin;

  const HomeScreen({
    Key? key,
    required this.userName,
    required this.userRole,
    this.isMainAdmin = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header with Image 1 logo (width 120, height 120, circle, border #D4AF37 width 3, shadow)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(top: 40, bottom: 20, left: 16, right: 16),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF04201E), Color(0xFF0A2E2B), Color(0xFF0D3B37)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                children: [
                  const Text(
                    'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
                    style: TextStyle(
                      color: Color(0xFFD4AF37),
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Logo container matching specification
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(color: const Color(0xFFD4AF37), width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black38,
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/logo.png',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                            const Icon(Icons.school, size: 60, color: Color(0xFF0A2E2B)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'স্থাপিত: ২০১৩ খ্রিষ্টাব্দ',
                    style: TextStyle(color: Color(0xFFD4AF37), fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'প্রধান পরিচালক: MD Muhi Uddin, মোবাইল: 01715047342',
                    style: TextStyle(color: Colors.white70, fontSize: 11),
                  ),
                ],
              ),
            ),

            // Dashboard Content
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Welcome Card
                  Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          const CircleAvatar(
                            radius: 24,
                            backgroundColor: Color(0xFF0A2E2B),
                            child: Icon(Icons.person, color: Color(0xFFD4AF37)),
                          ),
                          const SizedBox(width: 14),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                userName,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                              Text(
                                isMainAdmin ? 'প্রধান পরিচালক' : 'পদবী: $userRole',
                                style: const TextStyle(color: Colors.grey, fontSize: 12),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Admin Approval Button if Admin
                  if (isMainAdmin || userRole == 'Admin' || userRole == 'main') ...[
                    Card(
                      color: const Color(0xFFFEF3C7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: ListTile(
                        leading: const Icon(Icons.admin_panel_settings, color: Color(0xFFD97706)),
                        title: const Text(
                          'এডমিন অনুমোদন স্ক্রিন (রিকোয়েস্ট বক্স)',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        subtitle: const Text('পেন্ডিং রেজিস্ট্রেশন আবেদনসমূহ দেখুন ও অনুমোদন করুন'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const AdminApprovalScreen()),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  const Text(
                    'প্রধান কার্যক্রমসমূহ',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0A2E2B),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Action Buttons Grid
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    children: [
                      _buildMenuCard(
                        icon: Icons.book,
                        color: Colors.teal,
                        title: 'আজকের সবক',
                        subtitle: 'সবক পর্যবেক্ষণ',
                        onTap: () {},
                      ),
                      _buildMenuCard(
                        icon: Icons.school,
                        color: Colors.blue,
                        title: 'ছাত্র তালিকা',
                        subtitle: 'প্রোফাইল ও তথ্য',
                        onTap: () {},
                      ),
                      _buildMenuCard(
                        icon: Icons.calendar_today,
                        color: Colors.orange,
                        title: 'ক্লাস ও কাজের রুটিন',
                        subtitle: 'দৈনিক সূচি',
                        onTap: () {},
                      ),
                      _buildMenuCard(
                        icon: Icons.payment,
                        color: Colors.green,
                        title: 'ফি কালেকশন',
                        subtitle: 'আদায় ও রসিদ',
                        onTap: () {},
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuCard({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                backgroundColor: color.withOpacity(0.15),
                foregroundColor: color,
                child: Icon(icon),
              ),
              const SizedBox(height: 10),
              Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              Text(
                subtitle,
                style: const TextStyle(color: Colors.grey, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
