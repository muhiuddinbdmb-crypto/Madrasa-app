import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AdminApprovalScreen extends StatelessWidget {
  const AdminApprovalScreen({Key? key}) : super(key: key);

  void _approveRequest(BuildContext context, DocumentSnapshot doc) async {
    final data = doc.data() as Map<String, dynamic>;
    final name = data['name'] ?? '';
    final mobile = data['mobile'] ?? '';
    final email = data['email'] ?? '${mobile}@madrasa.org';
    final password = data['password'] ?? '123456';
    final role = data['role'] ?? 'Teacher';

    try {
      String uid = doc.id;
      try {
        final userCredential = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: email, password: password);
        uid = userCredential.user?.uid ?? doc.id;
      } catch (authError) {
        debugPrint('Auth creation note (using doc ID as uid): $authError');
      }

      // Add to users collection
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'uid': uid,
        'name': name,
        'email': email,
        'mobile': mobile,
        'password': password,
        'role': role,
        'approved': true,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Update pending_requests status to approved
      await doc.reference.update({'status': 'approved'});

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$name-এর আবেদন অনুমোদিত হয়েছে!'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('অনুমোদনে সমস্যা: $e'), backgroundColor: Colors.red),
      );
    }
  }

  void _rejectRequest(BuildContext context, DocumentSnapshot doc) async {
    try {
      await doc.reference.update({'status': 'rejected'});
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('আবেদনটি বাতিল করা হয়েছে।'), backgroundColor: Colors.orange),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('বাতিল করতে সমস্যা: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('এডমিন অনুমোদন স্ক্রিন', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0A2E2B),
        foregroundColor: Colors.white,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('pending_requests')
            .where('status', isEqualTo: 'pending')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('ত্রুটি: ${snapshot.error}'));
          }

          final docs = snapshot.data?.docs ?? [];

          if (docs.isEmpty) {
            return const Center(
              child: Text(
                'কোনো পেন্ডিং রিকোয়েস্ট নেই',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data() as Map<String, dynamic>;
              final name = data['name'] ?? 'নাম নেই';
              final mobile = data['mobile'] ?? '';
              final role = data['role'] ?? 'Teacher';
              final feeDue = data['feeDue'] ?? 500;
              final feePaid = data['feePaid'] ?? false;

              return Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 3,
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            name,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF0A2E2B),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: role == 'Admin' ? Colors.amber.shade100 : Colors.teal.shade50,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              role,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                color: role == 'Admin' ? Colors.brown : Colors.teal.shade800,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text('মোবাইল: $mobile', style: const TextStyle(color: Colors.black87)),
                      if (data['email'] != null && data['email'].toString().isNotEmpty)
                        Text('ইমেইল: ${data['email']}', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                      if (role == 'Admin') ...[
                        const SizedBox(height: 6),
                        Text(
                          'রেজিস্ট্রেশন ফি: ৳$feeDue (${feePaid ? "পরিশোধিত" : "বকেয়া"}) + মাসিক ৳২০০',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: feePaid ? Colors.green : Colors.deepOrange,
                          ),
                        ),
                      ],
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF2E7D32),
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              onPressed: () => _approveRequest(context, doc),
                              icon: const Icon(Icons.check, size: 18),
                              label: const Text('Approve'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red.shade700,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              onPressed: () => _rejectRequest(context, doc),
                              icon: const Icon(Icons.close, size: 18),
                              label: const Text('Reject'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
