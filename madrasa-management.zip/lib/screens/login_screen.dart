import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _identifierController =
      TextEditingController(text: 'muhiuddin.bd.mb@gmail.com');
  final TextEditingController _passwordController =
      TextEditingController(text: 'MS723926MS');
  bool _obscurePassword = true;
  bool _isLoading = false;
  String? _errorMessage;

  void _login() async {
    final identifier = _identifierController.text.trim();
    final password = _passwordController.text.trim();

    if (identifier.isEmpty || password.isEmpty) {
      setState(() => _errorMessage = 'মোবাইল বা ইমেইল এবং পাসওয়ার্ড দিন');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    // 1. Direct Main Admin check
    if ((identifier.toLowerCase() == 'muhiuddin.bd.mb@gmail.com' ||
            identifier == '01715047342') &&
        password == 'MS723926MS') {
      setState(() => _isLoading = false);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const HomeScreen(
            userName: 'MD Muhi Uddin',
            userRole: 'main',
            isMainAdmin: true,
          ),
        ),
      );
      return;
    }

    try {
      // 2. Check pending_requests by mobile or email
      var pendingSnap = await FirebaseFirestore.instance
          .collection('pending_requests')
          .where('mobile', isEqualTo: identifier)
          .where('status', isEqualTo: 'pending')
          .get();

      if (pendingSnap.docs.isEmpty) {
        pendingSnap = await FirebaseFirestore.instance
            .collection('pending_requests')
            .where('email', isEqualTo: identifier)
            .where('status', isEqualTo: 'pending')
            .get();
      }

      if (pendingSnap.docs.isNotEmpty) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Not approved yet (আপনার রেজিস্ট্রেশন রিকোয়েস্ট এখনও এপ্রুভ হয়নি)';
        });
        return;
      }

      // 3. Check users collection by mobile or email
      var usersSnap = await FirebaseFirestore.instance
          .collection('users')
          .where('mobile', isEqualTo: identifier)
          .get();

      if (usersSnap.docs.isEmpty) {
        usersSnap = await FirebaseFirestore.instance
            .collection('users')
            .where('email', isEqualTo: identifier)
            .get();
      }

      if (usersSnap.docs.isNotEmpty) {
        final userData = usersSnap.docs.first.data();
        final bool isApproved = userData['approved'] == true;

        if (!isApproved) {
          setState(() {
            _isLoading = false;
            _errorMessage = 'Not approved yet (আপনার আইডি এখনও এপ্রুভ হয়নি)';
          });
          return;
        }

        // Verify password if stored in doc
        if (userData['password'] != null &&
            userData['password'].toString().isNotEmpty &&
            userData['password'] != password) {
          setState(() {
            _isLoading = false;
            _errorMessage = 'ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন।';
          });
          return;
        }

        // Login success with role
        setState(() => _isLoading = false);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => HomeScreen(
              userName: userData['name'] ?? 'ব্যবহারকারী',
              userRole: userData['role'] ?? 'user',
              isMainAdmin: userData['role'] == 'main',
            ),
          ),
        );
        return;
      }

      setState(() {
        _isLoading = false;
        _errorMessage = 'কোনো অনুমোদিত একাউন্ট পাওয়া যায়নি। অনুগ্রহ করে রেজিস্ট্রেশন করুন।';
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'সংযোগ ত্রুটি: $e';
      });
    }
  }

  void _showRegistrationDialog() {
    final nameCtrl = TextEditingController();
    final mobileCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    final passCtrl = TextEditingController();
    final confirmPassCtrl = TextEditingController();
    String selectedRole = 'Admin'; // Default or Teacher

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Row(
            children: [
              Icon(Icons.person_add, color: Color(0xFF0A2E2B)),
              SizedBox(width: 8),
              Text(
                'রেজিস্ট্রেশন ফর্ম',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'পূর্ণ নাম (বাংলায়) *',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: mobileCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'মোবাইল নম্বর *',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'ইমেইল এড্রেস',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: passCtrl,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'পাসওয়ার্ড *',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: confirmPassCtrl,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'পাসওয়ার্ড নিশ্চিত করুন *',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Select Role (পদবী নির্বাচন):',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                ),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: selectedRole,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'Admin',
                      child: Text('Admin (অন্য মাদ্রাসা এডমিন)'),
                    ),
                    DropdownMenuItem(
                      value: 'Teacher',
                      child: Text('Teacher (শিক্ষক)'),
                    ),
                    DropdownMenuItem(
                      value: 'Guardian',
                      child: Text('Guardian (অভিভাবক)'),
                    ),
                  ],
                  onChanged: (val) {
                    if (val != null) {
                      setDialogState(() => selectedRole = val);
                    }
                  },
                ),
                // Show fees ONLY for Admin role (Issue 5: First registration 500tk + Monthly 200tk)
                if (selectedRole == 'Admin') ...[
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFFBEB),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFD4AF37), width: 1.5),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.info_outline, color: Color(0xFFB45309), size: 18),
                            SizedBox(width: 6),
                            Text(
                              'অন্য মাদ্রাসা রেজিস্ট্রেশন ফি',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF92400E),
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 6),
                        Text(
                          '• ১ম রেজিস্ট্রেশন ফি: ৫০০ টাকা',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF78350F),
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          '• মাসিক ফি: ২০০ টাকা',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF78350F),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('বাতিল'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2E7D32),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () async {
                if (nameCtrl.text.trim().isEmpty ||
                    mobileCtrl.text.trim().isEmpty ||
                    passCtrl.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('দয়া করে সকল বাধ্যতামূলক তথ্য পূরণ করুন')),
                  );
                  return;
                }
                if (passCtrl.text != confirmPassCtrl.text) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('পাসওয়ার্ড মিলছে না!')),
                  );
                  return;
                }

                Navigator.pop(ctx);

                // Save to Firestore pending_requests
                final bool isAdminRole = selectedRole == 'Admin';
                try {
                  await FirebaseFirestore.instance.collection('pending_requests').add({
                    'name': nameCtrl.text.trim(),
                    'mobile': mobileCtrl.text.trim(),
                    'email': emailCtrl.text.trim(),
                    'password': passCtrl.text.trim(),
                    'role': selectedRole,
                    'status': 'pending',
                    'feeDue': isAdminRole ? 500 : 0,
                    'monthlyFee': isAdminRole ? 200 : 0,
                    'feePaid': false,
                    'createdAt': FieldValue.serverTimestamp(),
                  });
                } catch (e) {
                  debugPrint('pending_requests write note: $e');
                }

                // Show SnackBar required in Issue 2
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    backgroundColor: Color(0xFF0A2E2B),
                    content: Text(
                      'আপনার রেজিস্ট্রেশন রিকোয়েস্ট এডমিনের কাছে গেছে। এপ্রুভ হলে লগইন করতে পারবেন।',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                    duration: Duration(seconds: 5),
                  ),
                );
              },
              child: const Text('রিকোয়েস্ট পাঠান'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF031A18), Color(0xFF0A2E2B), Color(0xFF0D3B36)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Logo container matching Issue 1
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(color: const Color(0xFFD4AF37), width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/logo.png',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                            const Icon(Icons.school, size: 60, color: Color(0xFF0A2E2B)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'মাদ্রাসা ম্যানেজমেন্ট সিস্টেমে স্বাগতম',
                    style: TextStyle(color: Color(0xFFD4AF37), fontSize: 13),
                  ),
                  const SizedBox(height: 24),
                  // Login Box
                  Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    elevation: 8,
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: [
                          const Text(
                            'লগইন করুন',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF0A2E2B),
                            ),
                          ),
                          if (_errorMessage != null) ...[
                            const SizedBox(height: 12),
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.red.shade50,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                _errorMessage!,
                                style: const TextStyle(color: Colors.red, fontSize: 12),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                          const SizedBox(height: 16),
                          TextField(
                            controller: _identifierController,
                            decoration: const InputDecoration(
                              labelText: 'ইমেইল অথবা মোবাইল নম্বর',
                              prefixIcon: Icon(Icons.email, color: Color(0xFF0A2E2B)),
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _passwordController,
                            obscureText: _obscurePassword,
                            decoration: InputDecoration(
                              labelText: 'পাসওয়ার্ড',
                              prefixIcon: const Icon(Icons.lock, color: Color(0xFF0A2E2B)),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _obscurePassword ? Icons.visibility_off : Icons.visibility,
                                  color: Colors.grey,
                                ),
                                onPressed: () =>
                                    setState(() => _obscurePassword = !_obscurePassword),
                              ),
                              border: const OutlineInputBorder(),
                              isDense: true,
                            ),
                          ),
                          const SizedBox(height: 18),
                          SizedBox(
                            width: double.infinity,
                            height: 48,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF2E7D32),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: _isLoading ? null : _login,
                              child: _isLoading
                                  ? const CircularProgressIndicator(color: Colors.white)
                                  : const Text(
                                      'প্রবেশ করুন',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Button text MUST BE ONLY "Registration" (Issue 2)
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFFD4AF37)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: _showRegistrationDialog,
                      icon: const Icon(Icons.person_add, color: Color(0xFFD4AF37)),
                      label: const Text(
                        'Registration',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
