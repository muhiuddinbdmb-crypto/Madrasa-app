import 'package:flutter/material.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final bool showLogo;

  const CustomAppBar({
    Key? key,
    this.title = 'মাদ্রাসা ম্যানেজমেন্ট',
    this.showLogo = true,
  }) : super(key: key);

  @override
  Size get preferredSize => const Size.fromHeight(160);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF04201E), Color(0xFF0A2E2B), Color(0xFF0D3B37)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (showLogo)
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFFD4AF37), width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 6,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/logo.png',
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          const Icon(Icons.school, size: 36, color: Color(0xFF0A2E2B)),
                    ),
                  ),
                ),
              const SizedBox(height: 6),
              const Text(
                'হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              const Text(
                'প্রধান পরিচালক: MD Muhi Uddin, মোবাইল: 01715047342',
                style: TextStyle(color: Color(0xFFD4AF37), fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
