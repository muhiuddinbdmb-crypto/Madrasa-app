import React from 'react';
import { Home, GraduationCap, Calendar, CreditCard, Menu } from 'lucide-react';
import { ScreenType } from '../types';

interface FloatingBottomNavBarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
}

export const FloatingBottomNavBar: React.FC<FloatingBottomNavBarProps> = ({
  currentScreen,
  onNavigate
}) => {
  const navItems: { title: string; screen: ScreenType; icon: React.ReactNode }[] = [
    { title: 'হোম', screen: 'home', icon: <Home className="w-5 h-5" /> },
    { title: 'ছাত্রগণ', screen: 'studentTable', icon: <GraduationCap className="w-5 h-5" /> },
    { title: 'রুটিন', screen: 'routine', icon: <Calendar className="w-5 h-5" /> },
    { title: 'ফি', screen: 'fee', icon: <CreditCard className="w-5 h-5" /> },
    { title: 'মেনু', screen: 'settings', icon: <Menu className="w-5 h-5" /> }
  ];

  return (
    <div className="fixed bottom-3 inset-x-0 z-40 px-4 max-w-lg mx-auto pointer-events-none">
      <div className="bg-white/95 backdrop-blur-md rounded-full shadow-2xl border border-slate-200/80 px-2 py-1.5 flex items-center justify-around pointer-events-auto">
        {navItems.map((item) => {
          const isSelected =
            currentScreen === item.screen ||
            (item.screen === 'settings' &&
              (currentScreen === 'settings' || currentScreen === 'adminManagement'));

          if (isSelected) {
            return (
              <button
                key={item.title}
                onClick={() => onNavigate(item.screen)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-[#2E7D32] text-white shadow-md transition-all duration-200"
              >
                {item.icon}
                <span className="text-xs font-bold whitespace-nowrap">{item.title}</span>
              </button>
            );
          }

          return (
            <button
              key={item.title}
              onClick={() => onNavigate(item.screen)}
              className="flex items-center gap-1 px-2.5 py-2 rounded-full text-slate-500 hover:text-emerald-800 transition-colors duration-150"
            >
              {item.icon}
              <span className="text-xs font-medium">{item.title}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
