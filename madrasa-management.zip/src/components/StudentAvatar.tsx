import React from 'react';
import { User } from 'lucide-react';

interface StudentAvatarProps {
  photoUrl?: string;
  name: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const StudentAvatar: React.FC<StudentAvatarProps> = ({
  photoUrl,
  name,
  size = 'md',
  className = ''
}) => {
  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-base',
    xl: 'w-20 h-20 text-xl'
  };

  const initial = name ? name.trim().charAt(0) : '';

  if (photoUrl && photoUrl.trim().length > 0) {
    return (
      <div
        className={`rounded-full overflow-hidden border-2 border-emerald-900/20 bg-emerald-50 flex items-center justify-center shrink-0 ${sizeClasses[size]} ${className}`}
      >
        <img
          src={photoUrl}
          alt={name}
          className="w-full h-full object-cover"
          onError={(e) => {
            // Fallback if image fails to load
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </div>
    );
  }

  return (
    <div
      className={`rounded-full border-2 border-emerald-900/20 bg-emerald-100 text-emerald-900 font-bold flex items-center justify-center shrink-0 shadow-sm ${sizeClasses[size]} ${className}`}
    >
      {initial ? initial : <User className="w-1/2 h-1/2 text-emerald-800" />}
    </div>
  );
};
