import React from 'react';

interface MadrasaLogoProps {
  size?: number;
  className?: string;
  withContainer?: boolean;
}

export const MadrasaLogo: React.FC<MadrasaLogoProps> = ({
  size = 120,
  className = '',
  withContainer = true
}) => {
  const content = (
    <svg
      viewBox="0 0 600 600"
      width={size}
      height={size}
      className="w-full h-full select-none"
    >
      <defs>
        <linearGradient id="mlGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F5D77F" />
          <stop offset="50%" stopColor="#D4AF37" />
          <stop offset="100%" stopColor="#A88926" />
        </linearGradient>
        <linearGradient id="mlBlueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0B3056" />
          <stop offset="50%" stopColor="#0A3464" />
          <stop offset="100%" stopColor="#061D3A" />
        </linearGradient>
        <linearGradient id="mlCenterGreen" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#558B2F" />
          <stop offset="35%" stopColor="#2E6930" />
          <stop offset="100%" stopColor="#1B4D25" />
        </linearGradient>
        <radialGradient id="mlCream" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="70%" stopColor="#FBF8EE" />
          <stop offset="100%" stopColor="#EFE5CB" />
        </radialGradient>
        <linearGradient id="mlFlame" x1="0%" y1="100%" x2="0%" y2="0%">
          <stop offset="0%" stopColor="#E65100" />
          <stop offset="30%" stopColor="#F57C00" />
          <stop offset="70%" stopColor="#FFB74D" />
          <stop offset="100%" stopColor="#FFF9C4" />
        </linearGradient>

        <path id="mlTopArc" d="M 68 300 A 232 232 0 1 1 532 300" fill="none" />
        <path id="mlBottomArc" d="M 510 322 A 214 214 0 0 1 90 322" fill="none" />
      </defs>

      {/* Outer base white */}
      <circle cx="300" cy="300" r="290" fill="#FFFFFF" />

      {/* Gold outer rim */}
      <circle cx="300" cy="300" r="282" fill="none" stroke="url(#mlGoldGrad)" strokeWidth="6" />
      <circle cx="300" cy="300" r="275" fill="none" stroke="#D4AF37" strokeWidth="2" />

      {/* Royal Navy Blue ring */}
      <circle cx="300" cy="300" r="240" fill="none" stroke="url(#mlBlueGrad)" strokeWidth="68" />

      {/* Inner gold borders */}
      <circle cx="300" cy="300" r="206" fill="none" stroke="#D4AF37" strokeWidth="2" />
      <circle cx="300" cy="300" r="202" fill="none" stroke="url(#mlGoldGrad)" strokeWidth="6" />

      {/* Gold decorative dots on ring */}
      <circle cx="86" cy="312" r="8" fill="url(#mlGoldGrad)" />
      <circle cx="514" cy="312" r="8" fill="url(#mlGoldGrad)" />

      {/* Top curved Bengali title: হযরত শাহজালাল (রঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা */}
      <text
        fill="#FFFFFF"
        fontFamily="'Noto Sans Bengali', sans-serif"
        fontSize="28"
        fontWeight="800"
        letterSpacing="1.5"
      >
        <textPath href="#mlTopArc" startOffset="50%" textAnchor="middle">
          হযরত শাহজালাল (রঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা
        </textPath>
      </text>

      {/* Bottom curved Bengali location: কচুরকান্দি, রসুলগঞ্জ, সুনামগঞ্জ */}
      <text
        fill="#FFFFFF"
        fontFamily="'Noto Sans Bengali', sans-serif"
        fontSize="25"
        fontWeight="800"
        letterSpacing="2.5"
      >
        <textPath href="#mlBottomArc" startOffset="50%" textAnchor="middle">
          কচুরকান্দি, রসুলগঞ্জ, সুনামগঞ্জ
        </textPath>
      </text>

      {/* Inner circular canvas */}
      <circle cx="300" cy="300" r="197" fill="url(#mlCream)" />

      {/* Center Mihrab arch background */}
      <path
        d="M 175 390 L 175 250 C 175 190 220 148 300 135 C 380 148 425 190 425 250 L 425 390 Z"
        fill="url(#mlCenterGreen)"
        stroke="url(#mlGoldGrad)"
        strokeWidth="4"
      />

      {/* Arabic Calligraphy: আল্লাহ */}
      <text
        x="300"
        y="172"
        textAnchor="middle"
        fill="#FFFFFF"
        fontFamily="'Amiri', serif"
        fontSize="34"
        fontWeight="bold"
      >
        আল্লাহ
      </text>

      {/* Emerald Green Dome in Center */}
      <path
        d="M 230 330 C 230 250 270 200 300 180 C 330 200 370 250 370 330 Z"
        fill="#0D4B2D"
        stroke="url(#mlGoldGrad)"
        strokeWidth="3"
      />

      {/* Top Pinnacle Crescent & Star */}
      <path d="M 296 172 A 9 9 0 1 1 308 184 A 11 11 0 1 0 296 172 Z" fill="url(#mlGoldGrad)" />
      <polygon
        points="305,170 307,175 312,175 308,178 310,183 305,180 301,183 303,178 299,175 304,175"
        fill="url(#mlGoldGrad)"
        transform="scale(0.8) translate(75, 40)"
      />

      {/* Center Dome Crescent & Star */}
      <path d="M 288 260 A 20 20 0 1 1 316 286 A 25 25 0 1 0 288 260 Z" fill="url(#mlGoldGrad)" />
      <polygon
        points="306,260 309,267 317,267 311,272 313,279 306,275 300,279 302,272 296,267 304,267"
        fill="url(#mlGoldGrad)"
      />

      {/* Right Mashaal / Torch */}
      <g transform="translate(390, 215)">
        <path d="M 25 35 C 10 20 20 0 25 -25 C 32 -5 45 15 35 35 Z" fill="url(#mlFlame)" />
        <path d="M 25 30 C 18 18 22 5 25 -10 C 29 5 35 15 30 30 Z" fill="#FFF9C4" />
        <path d="M 12 35 L 38 35 L 30 65 L 20 65 Z" fill="url(#mlGoldGrad)" stroke="#8C6615" strokeWidth="1.5" />
        <rect x="18" y="65" width="14" height="6" fill="#8C6615" rx="1" />
        <rect x="22" y="71" width="6" height="85" fill="#0A3464" stroke="url(#mlGoldGrad)" strokeWidth="1.5" />
        <rect x="20" y="105" width="10" height="4" fill="url(#mlGoldGrad)" />
        <rect x="20" y="135" width="10" height="4" fill="url(#mlGoldGrad)" />
      </g>

      {/* Open Quran Book */}
      <g transform="translate(195, 290)">
        <ellipse cx="105" cy="85" rx="90" ry="12" fill="rgba(0,0,0,0.25)" />

        {/* Left Page */}
        <path
          d="M 105 75 C 70 70 30 75 10 85 L 10 25 C 35 15 75 12 105 20 Z"
          fill="#FFFFFF"
          stroke="url(#mlGoldGrad)"
          strokeWidth="3"
        />
        {/* Right Page */}
        <path
          d="M 105 75 C 140 70 180 75 200 85 L 200 25 C 175 15 135 12 105 20 Z"
          fill="#FFFFFF"
          stroke="url(#mlGoldGrad)"
          strokeWidth="3"
        />

        {/* Quran Calligraphy */}
        <text
          x="56"
          y="52"
          fontFamily="'Amiri', serif"
          fontSize="21"
          fontWeight="bold"
          fill="#0A2E2B"
          textAnchor="middle"
        >
          القرآن
        </text>
        <text
          x="154"
          y="52"
          fontFamily="'Amiri', serif"
          fontSize="21"
          fontWeight="bold"
          fill="#0A2E2B"
          textAnchor="middle"
        >
          الكريم
        </text>

        {/* Rehal stand */}
        <polygon
          points="105,75 75,120 90,125 105,95 120,125 135,120"
          fill="#0D3B24"
          stroke="url(#mlGoldGrad)"
          strokeWidth="2"
        />
        <polygon
          points="50,115 105,80 160,115 145,122 105,90 65,122"
          fill="#092919"
          stroke="url(#mlGoldGrad)"
          strokeWidth="1.5"
        />
      </g>

      {/* Olive branch wreath */}
      <g fill="#2E7D32" stroke="#1B5E20" strokeWidth="1" transform="translate(160, 420)">
        <path d="M 30 20 Q 20 0 0 0 Q 5 15 30 20 Z" />
        <path d="M 45 15 Q 35 -5 18 -5 Q 22 10 45 15 Z" />
        <path d="M 60 10 Q 50 -10 35 -10 Q 38 5 60 10 Z" />
        <path d="M 75 5 Q 65 -15 50 -15 Q 52 0 75 5 Z" />
      </g>
      <g fill="#2E7D32" stroke="#1B5E20" strokeWidth="1" transform="translate(365, 420)">
        <path d="M 45 20 Q 55 0 75 0 Q 70 15 45 20 Z" />
        <path d="M 30 15 Q 40 -5 57 -5 Q 53 10 30 15 Z" />
        <path d="M 15 10 Q 25 -10 40 -10 Q 37 5 15 10 Z" />
        <path d="M 0 5 Q 10 -15 25 -15 Q 23 0 0 5 Z" />
      </g>

      {/* Established 2013 */}
      <text
        x="300"
        y="458"
        textAnchor="middle"
        fill="#0B2B1B"
        fontFamily="'Noto Sans Bengali', sans-serif"
        fontSize="24"
        fontWeight="bold"
      >
        স্থাপিত ২০১৩
      </text>
    </svg>
  );

  if (!withContainer) {
    return <div className={`inline-block ${className}`}>{content}</div>;
  }

  // Exact design specification from user:
  // Container width 120 height 120, decoration: BoxDecoration shape: BoxShape.circle, color: Colors.white, border: Border.all color #D4AF37 width 3, boxShadow.
  return (
    <div
      style={{
        width: `${size}px`,
        height: `${size}px`,
        backgroundColor: '#FFFFFF',
        borderColor: '#D4AF37',
        borderWidth: '3px',
        borderStyle: 'solid',
        borderRadius: '9999px',
        boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.2), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
      }}
      className={`overflow-hidden flex items-center justify-center p-0.5 ${className}`}
    >
      {content}
    </div>
  );
};
