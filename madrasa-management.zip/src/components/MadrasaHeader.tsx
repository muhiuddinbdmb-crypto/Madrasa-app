import React from 'react';
import { Cloud, RefreshCw, Phone } from 'lucide-react';
import { MadrasaLogo } from './MadrasaLogo';

interface MadrasaHeaderProps {
  syncStatusText: string;
  isSyncing: boolean;
}

export const MadrasaHeader: React.FC<MadrasaHeaderProps> = ({
  syncStatusText,
  isSyncing
}) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-[#04201E] via-[#0A2E2B] to-[#0D3B37] text-white pt-4 pb-6 px-4 shadow-md">
      {/* Islamic geometric pattern overlay background */}
      <div 
        className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#D4AF37_1px,transparent_1px)] [background-size:16px_16px]"
      />

      <div className="relative z-10 max-w-xl mx-auto flex flex-col items-center text-center">
        {/* Online Sync Indicator */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/35 backdrop-blur-sm text-xs font-medium text-emerald-300 mb-2 border border-emerald-500/20 shadow-sm">
          {isSyncing ? (
            <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
          ) : (
            <Cloud className="w-3.5 h-3.5 text-emerald-400" />
          )}
          <span className="text-[11px] text-white tracking-wide">{syncStatusText}</span>
        </div>

        {/* Bismillah in Arabic calligraphy */}
        <h2 className="font-arabic text-amber-400 text-lg md:text-xl font-bold tracking-wide drop-shadow-sm mb-2.5">
          بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
        </h2>

        {/* Circular Logo with 120x120 white circle and #D4AF37 border */}
        <div className="mb-3">
          <MadrasaLogo size={120} />
        </div>

        {/* Madrasa Name Large Bold Bangla White */}
        <h1 className="text-white text-lg sm:text-xl font-extrabold leading-snug max-w-md drop-shadow">
          হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা
        </h1>

        {/* Established 2013 */}
        <p className="text-amber-300 font-semibold text-xs sm:text-sm mt-1">
          স্থাপিত: ২০১৩ খ্রিষ্টাব্দ
        </p>

        {/* Principal / Main Admin contact */}
        <div className="flex items-center gap-1.5 text-white/95 text-xs sm:text-sm font-medium mt-1">
          <Phone className="w-3.5 h-3.5 text-amber-300" />
          <span>প্রধান পরিচালক: MD Muhi Uddin, মোবাইল: 01715047342</span>
        </div>
      </div>
    </div>
  );
};
