export interface Student {
  id: string;
  roll: number;
  name: string;
  className: string;
  section: string;
  phone: string;
  fatherName: string;
  photoUrl: string; // URL or Base64 data URI
  active: boolean;
}

export interface Teacher {
  id: string;
  name: string;
  phone: string;
  designation: string;
  classAssigned: string;
  email: string;
}

export interface DailySobokItem {
  id: string;
  studentId: string;
  studentRoll: number;
  studentName: string;
  date: string; // YYYY-MM-DD
  completedSabaks: string[]; // ["সবক", "সাত সবক", "আম্মোক্তা"]
  selectedSabakType: string;
  mulSobokPara: string;
  mulSobokPage: string;
  satSobokPara: string;
  satSobokPage: string;
  ammoktaPara: string;
  ammoktaPage: string;
  isCompleted: boolean; // true only when ALL 3 are completed
  completedByTeacher: string;
  completedTime: string;
  targetPage: string;
}

export interface SabakHistoryRecord {
  id: string;
  studentId: string;
  studentRoll: number;
  studentName: string;
  date: string; // YYYY-MM-DD or DD/MM/YYYY
  sabakType: string; // "সবক", "সাত সবক", "আম্মোক্তা"
  para: string;
  page: string;
  teacherName: string;
  time: string;
  status: string; // "সম্পন্ন"
}

export interface RegistrationRequest {
  id: string;
  name: string; // Full Name in Bangla
  mobile: string;
  phone?: string;
  email: string;
  password?: string;
  role: 'Admin' | 'Teacher' | 'Guardian' | string;
  madrasaName?: string;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
  feeDue?: number; // 500
  monthlyFee?: number; // 200
  feePaid?: boolean; // false
  createdAt?: any;
}

export interface ClassRoutineItem {
  id: string;
  day: string;
  time: string;
  className: string;
  subject: string;
  teacherName: string;
}

export interface KajerRoutineItem {
  id: string;
  taskName: string;
  time: string;
  assignedPerson: string;
  status: string; // "সম্পন্ন", "চলমান", "অপেক্ষমাণ"
}

export interface PoraProgressItem {
  id: string;
  studentId: string;
  studentName: string;
  studentRoll: number;
  mainSobok: string;
  satSobok: string;
  ammokta: string;
  dailyTarget: string;
  progressNote: string;
  recordedBy: string;
  date: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentRoll: number;
  date: string;
  status: 'উপস্থিত' | 'অনুপস্থিত' | 'বিলম্ব';
}

export interface FeeRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentRoll: number;
  monthYear: string;
  amount: number;
  paidAmount: number;
  isPaid: boolean;
  paymentDate: string;
  receiptNumber: string;
}

export interface ExamResult {
  id: string;
  examName: string;
  studentName: string;
  studentRoll: number;
  subject: string;
  totalMarks: number;
  obtainedMarks: number;
  grade: string;
}

export interface NoticeItem {
  id: string;
  title: string;
  description: string;
  date: string;
  isImportant: boolean;
}

export interface MadrasaRegistration {
  id: string;
  madrasaName: string;
  address: string;
  adminName: string;
  email: string;
  phone: string;
  password?: string;
  status: 'PENDING' | 'APPROVED' | 'BLOCKED';
  registeredDate: string;
  paymentNote?: string;
}

export interface UserAccount {
  id: string;
  uid?: string;
  name: string;
  phone: string;
  mobile?: string;
  email: string;
  role: 'Admin' | 'Teacher' | 'Guardian' | 'main' | 'sub' | string;
  isMain: boolean;
  approved?: boolean;
  createdBy: string;
  studentRoll?: string;
  isActive: boolean;
  createdAt?: any;
}

export type ScreenType =
  | 'splash'
  | 'login'
  | 'otherMadrasaReg'
  | 'home'
  | 'dailySobok'
  | 'routine'
  | 'poraProgress'
  | 'studentTable'
  | 'teacherList'
  | 'attendance'
  | 'fee'
  | 'exam'
  | 'notice'
  | 'settings'
  | 'adminManagement'
  | 'otherMadrasaApprovals'
  | 'studentHistory'
  | 'registrationRequests';
