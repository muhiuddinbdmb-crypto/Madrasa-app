import {
  Student,
  Teacher,
  DailySobokItem,
  SabakHistoryRecord,
  RegistrationRequest,
  ClassRoutineItem,
  KajerRoutineItem,
  PoraProgressItem,
  AttendanceRecord,
  FeeRecord,
  ExamResult,
  NoticeItem,
  MadrasaRegistration,
  UserAccount
} from '../types';
import { db } from '../firebase';
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDocs,
  onSnapshot
} from 'firebase/firestore';

// Default initial data for fresh launch
const INITIAL_STUDENTS: Student[] = [
  {
    id: 'st_1',
    roll: 1,
    name: 'আব্দুর রহমান',
    className: 'হিফজুল কুরআন',
    section: 'ক শাখা',
    phone: '01711111111',
    fatherName: 'মাওলানা আব্দুল্লাহ',
    photoUrl: '',
    active: true
  },
  {
    id: 'st_2',
    roll: 2,
    name: 'মুহাম্মদ আব্দুল্লাহ',
    className: 'হিফজুল কুরআন',
    section: 'ক শাখা',
    phone: '01722222222',
    fatherName: 'হাফেজ উসমান',
    photoUrl: '',
    active: true
  },
  {
    id: 'st_3',
    roll: 3,
    name: 'ইবরাহীম খলিল',
    className: 'হিফজুল কুরআন',
    section: 'খ শাখা',
    phone: '01733333333',
    fatherName: 'মুহাম্মদ আবু বকর',
    photoUrl: '',
    active: true
  },
  {
    id: 'st_4',
    roll: 4,
    name: 'ইউসুফ আহমেদ',
    className: 'হিফজুল কুরআন',
    section: 'খ শাখা',
    phone: '01744444444',
    fatherName: 'মাওলানা ইয়াকুব',
    photoUrl: '',
    active: true
  }
];

const INITIAL_TEACHERS: Teacher[] = [
  {
    id: 'tc_1',
    name: 'মাওলানা আব্দুল হাফিজ',
    phone: '01755555555',
    designation: 'প্রধান শিক্ষক',
    classAssigned: 'হিফজুল কুরআন',
    email: 'hafiz@madrasa.org'
  },
  {
    id: 'tc_2',
    name: 'হাফেজ মুশতাক আহমেদ',
    phone: '01766666666',
    designation: 'সহকারী শিক্ষক',
    classAssigned: 'হিফজুল কুরআন ক শাখা',
    email: 'mushtaq@madrasa.org'
  }
];

const INITIAL_NOTICES: NoticeItem[] = [
  {
    id: 'nt_1',
    title: 'রমজানুল মোবারকের প্রস্তুতি ও সবক সময়সূচী',
    description: 'আগামী সপ্তাহ থেকে সকল ছাত্রছাত্রীদের সকাল ৭:০০ টা থেকে বাদ আসর পর্যন্ত বিশেষ সবক চলবে।',
    date: '০৮/১০/২০২৬',
    isImportant: true
  },
  {
    id: 'nt_2',
    title: 'মাসিক মূল্যায়ন পরীক্ষা',
    description: 'আগামী মাসের ১৫ তারিখে হিফজ ও নাজেরা বিভাগের মাসিক মূল্যায়ন পরীক্ষা অনুষ্ঠিত হবে ইনশাআল্লাহ।',
    date: '০৫/১০/২০২৬',
    isImportant: false
  }
];

const INITIAL_CLASS_ROUTINES: ClassRoutineItem[] = [
  { id: 'cr_1', day: 'শনিবার', time: '০৬:০০ - ০৮:০০', className: 'হিফজুল কুরআন', subject: 'নতুন সবক', teacherName: 'মাওলানা আব্দুল হাফিজ' },
  { id: 'cr_2', day: 'রবিবার', time: '০৮:০০ - ১০:০০', className: 'হিফজুল কুরআন', subject: 'সাত সবক', teacherName: 'হাফেজ মুশতাক আহমেদ' },
  { id: 'cr_3', day: 'সোমবার', time: '১০:০০ - ১২:০০', className: 'হিফজুল কুরআন', subject: 'আম্মোক্তা', teacherName: 'মাওলানা আব্দুল হাফিজ' }
];

const INITIAL_KAJER_ROUTINES: KajerRoutineItem[] = [
  { id: 'kr_1', taskName: 'ফজর পর সবক তদারকি', time: '০৫:৩০ AM', assignedPerson: 'হাফেজ মুশতাক', status: 'সম্পন্ন' },
  { id: 'kr_2', taskName: 'দুপুরের খাবার ও বিশ্রাম', time: '০১:৩০ PM', assignedPerson: 'বাবুর্চি ও খতিব', status: 'চলমান' },
  { id: 'kr_3', taskName: 'মাগরিব পর আম্মোক্তা শুনা', time: '০৬:১৫ PM', assignedPerson: 'মাওলানা আব্দুল হাফিজ', status: 'অপেক্ষমাণ' }
];

class MadrasaRepositoryService {
  private subscribers: Set<() => void> = new Set();
  
  users: UserAccount[] = [];
  students: Student[] = [];
  teachers: Teacher[] = [];
  dailySobokList: DailySobokItem[] = [];
  sabakHistory: SabakHistoryRecord[] = [];
  registrationRequests: RegistrationRequest[] = [];
  classRoutines: ClassRoutineItem[] = [];
  kajerRoutines: KajerRoutineItem[] = [];
  poraProgressList: PoraProgressItem[] = [];
  attendanceList: AttendanceRecord[] = [];
  feeList: FeeRecord[] = [];
  notices: NoticeItem[] = [];
  registrations: MadrasaRegistration[] = [];
  examResults: ExamResult[] = [];
  
  syncStatus: string = 'অনলাইন সিঙ্ক সম্পন্ন';
  isSyncing: boolean = false;
  
  constructor() {
    this.loadFromLocalStorage();
    this.ensureMainAdmin();
    this.setupFirestoreListeners();
  }

  subscribe(callback: () => void): () => void {
    this.subscribers.add(callback);
    return () => this.subscribers.delete(callback);
  }

  private notify() {
    this.subscribers.forEach((cb) => cb());
  }

  getTodayDateString(): string {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  // --- Main Admin Guarantee ---
  private ensureMainAdmin() {
    const mainAdminPhone = '01715047342';
    const mainAdminEmail = 'muhiuddin.bd.mb@gmail.com';
    const exists = this.users.some(
      (u) => u.isMain || u.phone === mainAdminPhone || u.email.toLowerCase() === mainAdminEmail.toLowerCase()
    );

    if (!exists) {
      const mainAdmin: UserAccount = {
        id: 'admin_main',
        name: 'MD Muhi Uddin',
        phone: mainAdminPhone,
        email: mainAdminEmail,
        role: 'main',
        isMain: true,
        createdBy: 'System',
        isActive: true
      };
      this.users.unshift(mainAdmin);
      this.savePasswordLocally(mainAdminEmail, 'MS723926MS');
      this.savePasswordLocally(mainAdminPhone, 'MS723926MS');
      this.saveToLocalStorage();
      this.syncAdminToFirestore(mainAdmin);
    }
  }

  savePasswordLocally(identifier: string, pass: string) {
    localStorage.setItem(`pwd_${identifier.trim().toLowerCase()}`, pass);
  }

  getPasswordLocally(identifier: string): string {
    const key = identifier.trim().toLowerCase();
    if (key === 'muhiuddin.bd.mb@gmail.com' || key === '01715047342') {
      return localStorage.getItem(`pwd_${key}`) || 'MS723926MS';
    }
    return localStorage.getItem(`pwd_${key}`) || '';
  }

  // --- Authentication ---
  login(identifier: string, pass: string): { user: UserAccount | null; error?: string } {
    const trimmedId = identifier.trim();
    const trimmedPass = pass.trim();

    // 1. Direct Main Admin check (MD Muhi Uddin is always approved)
    if (
      (trimmedId.toLowerCase() === 'muhiuddin.bd.mb@gmail.com' || trimmedId === '01715047342') &&
      trimmedPass === 'MS723926MS'
    ) {
      const mainAdmin = this.users.find((u) => u.isMain) || {
        id: 'admin_main',
        name: 'MD Muhi Uddin',
        phone: '01715047342',
        email: 'muhiuddin.bd.mb@gmail.com',
        role: 'main',
        isMain: true,
        approved: true,
        createdBy: 'System',
        isActive: true
      };
      return { user: mainAdmin };
    }

    // 2. Check if user is in pending_requests
    const pendingReq = this.registrationRequests.find(
      (r) =>
        (r.phone === trimmedId || r.mobile === trimmedId || (r.email && r.email.toLowerCase() === trimmedId.toLowerCase())) &&
        r.status === 'pending'
    );
    if (pendingReq) {
      return {
        user: null,
        error: 'Not approved yet (আপনার রেজিস্ট্রেশন রিকোয়েস্ট এখনও এডমিনের অনুমোদন পায়নি)'
      };
    }

    const rejectedReq = this.registrationRequests.find(
      (r) =>
        (r.phone === trimmedId || r.mobile === trimmedId || (r.email && r.email.toLowerCase() === trimmedId.toLowerCase())) &&
        r.status === 'rejected'
    );
    if (rejectedReq) {
      return {
        user: null,
        error: 'আপনার রেজিস্ট্রেশন রিকোয়েস্ট বাতিল করা হয়েছে।'
      };
    }

    // 3. Check among users collection: Must exist and approved == true
    const user = this.users.find(
      (u) =>
        (u.email.toLowerCase() === trimmedId.toLowerCase() ||
          u.phone === trimmedId ||
          u.mobile === trimmedId) &&
        u.isActive
    );

    if (user) {
      // Must have approved == true (unless main admin)
      if (!user.isMain && user.approved === false) {
        return {
          user: null,
          error: 'Not approved yet (আপনার আইডি এখনও অনুমোদিত হয়নি)'
        };
      }

      const savedPass =
        this.getPasswordLocally(user.email) ||
        this.getPasswordLocally(user.phone) ||
        (user.mobile ? this.getPasswordLocally(user.mobile) : '');

      if (savedPass === trimmedPass || (user.isMain && trimmedPass === 'MS723926MS')) {
        return { user };
      } else {
        return { user: null, error: 'ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন।' };
      }
    }

    // 4. Check among teachers
    const teacher = this.teachers.find(
      (t) => t.phone === trimmedId || (t.email && t.email.toLowerCase() === trimmedId.toLowerCase())
    );
    if (teacher) {
      const savedPass = this.getPasswordLocally(teacher.phone);
      if (savedPass === trimmedPass || trimmedPass === '123456') {
        return {
          user: {
            id: teacher.id,
            name: teacher.name,
            phone: teacher.phone,
            email: teacher.email,
            role: 'teacher',
            isMain: false,
            approved: true,
            createdBy: 'Admin',
            isActive: true
          }
        };
      } else {
        return { user: null, error: 'ভুল পাসওয়ার্ড!' };
      }
    }

    return {
      user: null,
      error: 'এই তথ্য দিয়ে কোনো ব্যবহারকারী পাওয়া যায়নি। অনুগ্রহ করে রেজিস্ট্রেশন করুন।'
    };
  }

  // --- Admin Management ---
  addSecondAdmin(name: string, phone: string, pass: string, creator: string): boolean {
    if (this.users.some((u) => u.phone === phone)) return false;
    const newAdmin: UserAccount = {
      id: `admin_${Date.now()}`,
      name,
      phone,
      email: '',
      role: 'sub',
      isMain: false,
      createdBy: creator,
      isActive: true
    };
    this.users.push(newAdmin);
    this.savePasswordLocally(phone, pass);
    this.saveToLocalStorage();
    this.syncAdminToFirestore(newAdmin);
    this.notify();
    return true;
  }

  deleteSecondAdmin(adminId: string): boolean {
    const target = this.users.find((u) => u.id === adminId);
    if (!target || target.isMain) return false; // Main Admin CANNOT be deleted
    this.users = this.users.filter((u) => u.id !== adminId);
    this.saveToLocalStorage();
    if (db) {
      deleteDoc(doc(db, 'admins', target.phone)).catch((e) => console.warn(e));
    }
    this.notify();
    return true;
  }

  // --- Student Management ---
  addStudent(student: Student) {
    this.students = [...this.students.filter((s) => s.id !== student.id), student].sort((a, b) => a.roll - b.roll);
    this.saveToLocalStorage();
    this.ensureTodaySobokForStudent(student);
    if (db) {
      setDoc(doc(db, 'students', student.id), student).catch((e) => console.warn(e));
    }
    this.notify();
  }

  deleteStudent(studentId: string) {
    this.students = this.students.filter((s) => s.id !== studentId);
    this.saveToLocalStorage();
    if (db) {
      deleteDoc(doc(db, 'students', studentId)).catch((e) => console.warn(e));
    }
    this.notify();
  }

  // --- Teacher Management ---
  addTeacher(teacher: Teacher, pass: string = '123456') {
    this.teachers = [...this.teachers.filter((t) => t.id !== teacher.id), teacher];
    this.savePasswordLocally(teacher.phone, pass);
    this.saveToLocalStorage();
    if (db) {
      setDoc(doc(db, 'teachers', teacher.id), teacher).catch((e) => console.warn(e));
    }
    this.notify();
  }

  deleteTeacher(teacherId: string) {
    this.teachers = this.teachers.filter((t) => t.id !== teacherId);
    this.saveToLocalStorage();
    if (db) {
      deleteDoc(doc(db, 'teachers', teacherId)).catch((e) => console.warn(e));
    }
    this.notify();
  }

  // --- Daily Sobok ---
  getTodaySobokList(): DailySobokItem[] {
    const today = this.getTodayDateString();
    const existingToday = this.dailySobokList.filter((s) => s.date === today);
    const existingIds = new Set(existingToday.map((s) => s.studentId));

    const missing = this.students
      .filter((s) => !existingIds.has(s.id))
      .map((s) => ({
        id: `sobok_${s.id}_${today}`,
        studentId: s.id,
        studentRoll: s.roll,
        studentName: s.name,
        date: today,
        completedSabaks: [],
        selectedSabakType: 'সবক',
        mulSobokPara: '',
        mulSobokPage: '',
        satSobokPara: '',
        satSobokPage: '',
        ammoktaPara: '',
        ammoktaPage: '',
        isCompleted: false,
        completedByTeacher: '',
        completedTime: '',
        targetPage: ''
      }));

    if (missing.length > 0) {
      this.dailySobokList = [...this.dailySobokList, ...missing];
      this.saveToLocalStorage();
    }

    // Sort: uncompleted on top, completed at bottom, secondary by roll
    const allThree = ['সবক', 'সাত সবক', 'আম্মোক্তা'];
    return this.dailySobokList
      .filter((s) => s.date === today)
      .sort((a, b) => {
        const aDone = a.completedSabaks.length >= 3 && allThree.every((t) => a.completedSabaks.includes(t));
        const bDone = b.completedSabaks.length >= 3 && allThree.every((t) => b.completedSabaks.includes(t));
        if (aDone === bDone) {
          return a.studentRoll - b.studentRoll;
        }
        return aDone ? 1 : -1;
      });
  }

  private ensureTodaySobokForStudent(student: Student) {
    const today = this.getTodayDateString();
    const exists = this.dailySobokList.some((s) => s.studentId === student.id && s.date === today);
    if (!exists) {
      const item: DailySobokItem = {
        id: `sobok_${student.id}_${today}`,
        studentId: student.id,
        studentRoll: student.roll,
        studentName: student.name,
        date: today,
        completedSabaks: [],
        selectedSabakType: 'সবক',
        mulSobokPara: '',
        mulSobokPage: '',
        satSobokPara: '',
        satSobokPage: '',
        ammoktaPara: '',
        ammoktaPage: '',
        isCompleted: false,
        completedByTeacher: '',
        completedTime: '',
        targetPage: ''
      };
      this.dailySobokList.push(item);
      this.saveToLocalStorage();
      if (db) {
        setDoc(doc(db, 'dailySobok', item.id), item).catch((e) => console.warn(e));
      }
    }
  }

  markSingleSabakCompleted(
    itemId: string,
    sabakType: string,
    para: string,
    page: string,
    teacherName: string
  ) {
    const timeStr = new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
    const today = this.getTodayDateString();
    const allThreeTypes = ['সবক', 'সাত সবক', 'আম্মোক্তা'];
    let savedRecord: SabakHistoryRecord | null = null;
    let targetUpdated: DailySobokItem | null = null;

    this.dailySobokList = this.dailySobokList.map((item) => {
      if (item.id === itemId) {
        const newCompleted = item.completedSabaks.includes(sabakType)
          ? item.completedSabaks
          : [...item.completedSabaks, sabakType];
        
        const isAllDone = allThreeTypes.every((t) => newCompleted.includes(t));
        const teacherLog = `যাচাইকারী: ${teacherName} - ${timeStr}`;

        const updated: DailySobokItem = {
          ...item,
          completedSabaks: newCompleted,
          isCompleted: isAllDone,
          completedByTeacher: teacherLog,
          completedTime: timeStr,
          mulSobokPara: sabakType === 'সবক' ? para || item.mulSobokPara : item.mulSobokPara,
          mulSobokPage: sabakType === 'সবক' ? page || item.mulSobokPage : item.mulSobokPage,
          satSobokPara: sabakType === 'সাত সবক' ? para || item.satSobokPara : item.satSobokPara,
          satSobokPage: sabakType === 'সাত সবক' ? page || item.satSobokPage : item.satSobokPage,
          ammoktaPara: sabakType === 'আম্মোক্তা' ? para || item.ammoktaPara : item.ammoktaPara,
          ammoktaPage: sabakType === 'আম্মোক্তা' ? page || item.ammoktaPage : item.ammoktaPage
        };

        savedRecord = {
          id: `hist_${item.studentId}_${Date.now()}`,
          studentId: item.studentId,
          studentRoll: item.studentRoll,
          studentName: item.studentName,
          date: today,
          sabakType,
          para,
          page,
          teacherName,
          time: timeStr,
          status: 'সম্পন্ন'
        };

        targetUpdated = updated;
        return updated;
      }
      return item;
    });

    if (savedRecord) {
      this.sabakHistory.unshift(savedRecord);
      if (db) {
        setDoc(doc(db, 'sabakHistory', (savedRecord as SabakHistoryRecord).id), savedRecord).catch((e) => console.warn(e));
      }
    }

    if (targetUpdated && db) {
      setDoc(doc(db, 'dailySobok', itemId), targetUpdated).catch((e) => console.warn(e));
    }

    this.saveToLocalStorage();
    this.notify();
  }

  deleteSabakHistoryRecord(historyId: string) {
    this.sabakHistory = this.sabakHistory.filter((h) => h.id !== historyId);
    this.saveToLocalStorage();
    if (db) {
      deleteDoc(doc(db, 'sabakHistory', historyId)).catch((e) => console.warn(e));
    }
    this.notify();
  }

  // --- Registration Requests (Issue 2 & 3: pending_requests collection) ---
  submitRegistrationRequest(req: RegistrationRequest) {
    const mobileNum = req.mobile || req.phone || '';
    const formattedReq: RegistrationRequest = {
      ...req,
      mobile: mobileNum,
      phone: mobileNum,
      status: 'pending',
      feeDue: req.feeDue ?? 500,
      monthlyFee: req.monthlyFee ?? 200,
      feePaid: req.feePaid ?? false,
      createdAt: req.createdAt || new Date().toISOString()
    };

    this.registrationRequests = [
      formattedReq,
      ...this.registrationRequests.filter((r) => r.id !== req.id)
    ];

    if (req.password) {
      this.savePasswordLocally(mobileNum, req.password);
      if (req.email) this.savePasswordLocally(req.email, req.password);
    }

    this.saveToLocalStorage();

    if (db) {
      // Save to pending_requests collection as explicitly required
      const firestoreData = {
        name: formattedReq.name,
        mobile: formattedReq.mobile,
        email: formattedReq.email,
        password: formattedReq.password,
        role: formattedReq.role,
        status: 'pending',
        feeDue: formattedReq.feeDue,
        monthlyFee: formattedReq.monthlyFee,
        feePaid: formattedReq.feePaid,
        createdAt: formattedReq.createdAt
      };
      setDoc(doc(db, 'pending_requests', req.id), firestoreData).catch((e) => console.warn(e));
      setDoc(doc(db, 'registrationRequests', req.id), formattedReq).catch((e) => console.warn(e));
    }
    this.notify();
  }

  approveRegistrationRequest(requestId: string) {
    const req = this.registrationRequests.find((r) => r.id === requestId);
    if (!req) return;
    req.status = 'approved';

    const mobileNum = req.mobile || req.phone || '';
    if (req.password) {
      this.savePasswordLocally(mobileNum, req.password);
      if (req.email) this.savePasswordLocally(req.email, req.password);
    }

    // Add to users collection with { uid, name, email, mobile, role, approved: true, createdAt }
    const newUser: UserAccount = {
      id: req.id,
      uid: req.id,
      name: req.name,
      phone: mobileNum,
      mobile: mobileNum,
      email: req.email,
      role: req.role,
      isMain: false,
      approved: true,
      createdBy: 'Approved by Admin',
      isActive: true,
      createdAt: new Date().toISOString()
    };
    this.users = [...this.users.filter((u) => u.id !== newUser.id), newUser];

    this.saveToLocalStorage();
    if (db) {
      // Update pending_requests status to approved
      setDoc(doc(db, 'pending_requests', requestId), { status: 'approved' }, { merge: true }).catch((e) =>
        console.warn(e)
      );
      setDoc(doc(db, 'registrationRequests', requestId), { status: 'approved' }, { merge: true }).catch((e) =>
        console.warn(e)
      );
      // Save to users collection with approved: true
      setDoc(doc(db, 'users', newUser.id), {
        uid: newUser.id,
        name: newUser.name,
        email: newUser.email,
        mobile: newUser.mobile,
        role: newUser.role,
        approved: true,
        createdAt: newUser.createdAt
      }).catch((e) => console.warn(e));
    }
    this.notify();
  }

  rejectRegistrationRequest(requestId: string) {
    this.registrationRequests = this.registrationRequests.map((r) =>
      r.id === requestId ? { ...r, status: 'rejected' } : r
    );
    this.saveToLocalStorage();
    if (db) {
      setDoc(doc(db, 'pending_requests', requestId), { status: 'rejected' }, { merge: true }).catch((e) =>
        console.warn(e)
      );
      setDoc(doc(db, 'registrationRequests', requestId), { status: 'rejected' }, { merge: true }).catch((e) =>
        console.warn(e)
      );
    }
    this.notify();
  }

  deleteRegistrationRequest(requestId: string) {
    this.registrationRequests = this.registrationRequests.filter((r) => r.id !== requestId);
    this.saveToLocalStorage();
    if (db) {
      deleteDoc(doc(db, 'pending_requests', requestId)).catch((e) => console.warn(e));
      deleteDoc(doc(db, 'registrationRequests', requestId)).catch((e) => console.warn(e));
    }
    this.notify();
  }

  // --- Routines ---
  addClassRoutine(item: ClassRoutineItem) {
    this.classRoutines.push(item);
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'classRoutine', item.id), item).catch((e) => console.warn(e));
    this.notify();
  }

  deleteClassRoutine(id: string) {
    this.classRoutines = this.classRoutines.filter((c) => c.id !== id);
    this.saveToLocalStorage();
    if (db) deleteDoc(doc(db, 'classRoutine', id)).catch((e) => console.warn(e));
    this.notify();
  }

  addKajerRoutine(item: KajerRoutineItem) {
    this.kajerRoutines.push(item);
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'kajerRoutine', item.id), item).catch((e) => console.warn(e));
    this.notify();
  }

  updateKajerRoutineStatus(id: string, status: string) {
    this.kajerRoutines = this.kajerRoutines.map((k) => (k.id === id ? { ...k, status } : k));
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'kajerRoutine', id), { status }, { merge: true }).catch((e) => console.warn(e));
    this.notify();
  }

  deleteKajerRoutine(id: string) {
    this.kajerRoutines = this.kajerRoutines.filter((k) => k.id !== id);
    this.saveToLocalStorage();
    if (db) deleteDoc(doc(db, 'kajerRoutine', id)).catch((e) => console.warn(e));
    this.notify();
  }

  // --- Pora Progress ---
  addPoraProgress(item: PoraProgressItem) {
    this.poraProgressList.unshift(item);
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'poraProgress', item.id), item).catch((e) => console.warn(e));
    this.notify();
  }

  // --- Attendance ---
  markAttendance(student: Student, date: string, status: 'উপস্থিত' | 'অনুপস্থিত' | 'বিলম্ব') {
    const id = `att_${student.id}_${date}`;
    const record: AttendanceRecord = {
      id,
      studentId: student.id,
      studentName: student.name,
      studentRoll: student.roll,
      date,
      status
    };
    this.attendanceList = [...this.attendanceList.filter((a) => a.id !== id), record];
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'attendance', id), record).catch((e) => console.warn(e));
    this.notify();
  }

  // --- Fees ---
  addFeeRecord(record: FeeRecord) {
    this.feeList.unshift(record);
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'fees', record.id), record).catch((e) => console.warn(e));
    this.notify();
  }

  markFeePaid(id: string, amount: number) {
    const dateStr = new Date().toLocaleDateString('bn-BD');
    const receiptNum = `REC-${Math.floor(1000 + Math.random() * 9000)}`;
    this.feeList = this.feeList.map((f) =>
      f.id === id
        ? {
            ...f,
            isPaid: true,
            paidAmount: amount,
            paymentDate: dateStr,
            receiptNumber: receiptNum
          }
        : f
    );
    this.saveToLocalStorage();
    const target = this.feeList.find((f) => f.id === id);
    if (target && db) setDoc(doc(db, 'fees', id), target).catch((e) => console.warn(e));
    this.notify();
  }

  // --- Notices ---
  addNotice(notice: NoticeItem) {
    this.notices.unshift(notice);
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'notices', notice.id), notice).catch((e) => console.warn(e));
    this.notify();
  }

  deleteNotice(id: string) {
    this.notices = this.notices.filter((n) => n.id !== id);
    this.saveToLocalStorage();
    if (db) deleteDoc(doc(db, 'notices', id)).catch((e) => console.warn(e));
    this.notify();
  }

  // --- Exam Results ---
  addExamResult(result: ExamResult) {
    this.examResults.unshift(result);
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'examResults', result.id), result).catch((e) => console.warn(e));
    this.notify();
  }

  // --- Other Madrasa Registration ---
  registerOtherMadrasa(reg: MadrasaRegistration) {
    this.registrations.unshift(reg);
    if (reg.password) {
      this.savePasswordLocally(reg.phone, reg.password);
    }
    // Also add to registrationRequests so Admin sees it in Request Box!
    const req: RegistrationRequest = {
      id: reg.id,
      name: reg.adminName,
      mobile: reg.phone,
      phone: reg.phone,
      email: reg.email,
      password: reg.password,
      role: 'Admin',
      madrasaName: reg.madrasaName,
      date: reg.registeredDate,
      status: 'pending',
      feeDue: 500,
      monthlyFee: 200,
      feePaid: false
    };
    this.submitRegistrationRequest(req);

    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'madrasaRegistrations', reg.id), reg).catch((e) => console.warn(e));
    this.notify();
  }

  updateMadrasaStatus(id: string, status: 'APPROVED' | 'BLOCKED') {
    this.registrations = this.registrations.map((r) => (r.id === id ? { ...r, status } : r));
    if (status === 'APPROVED') {
      this.approveRegistrationRequest(id);
    } else {
      this.rejectRegistrationRequest(id);
    }
    this.saveToLocalStorage();
    if (db) setDoc(doc(db, 'madrasaRegistrations', id), { status }, { merge: true }).catch((e) => console.warn(e));
    this.notify();
  }

  // --- Firestore Sync Helper ---
  private syncAdminToFirestore(admin: UserAccount) {
    if (!db) return;
    setDoc(doc(db, 'admins', admin.phone), {
      name: admin.name,
      phone: admin.phone,
      email: admin.email,
      role: admin.role,
      isMain: admin.isMain,
      createdBy: admin.createdBy
    }).catch((e) => console.warn('Firestore admin write warning:', e));
  }

  private setupFirestoreListeners() {
    if (!db) return;
    this.isSyncing = true;
    this.syncStatus = 'সিঙ্ক হচ্ছে...';
    this.notify();

    const handleSnapshotError = (colName: string) => (err: any) => {
      // Gracefully catch permission-denied and other errors so they do not crash or throw unhandled exceptions
      console.warn(`Firestore snapshot handled for ${colName}:`, err?.code || err?.message);
      this.isSyncing = false;
      this.syncStatus = 'স্থানীয় মোড সক্রিয়';
      this.notify();
    };

    try {
      onSnapshot(
        collection(db, 'students'),
        (snap) => {
          if (!snap.empty) {
            const list: Student[] = [];
            snap.forEach((d) => list.push(d.data() as Student));
            this.students = list.sort((a, b) => a.roll - b.roll);
            this.saveToLocalStorage();
            this.notify();
          }
          this.isSyncing = false;
          this.syncStatus = 'অনলাইন সিঙ্ক সম্পন্ন';
          this.notify();
        },
        handleSnapshotError('students')
      );

      onSnapshot(
        collection(db, 'teachers'),
        (snap) => {
          if (!snap.empty) {
            const list: Teacher[] = [];
            snap.forEach((d) => list.push(d.data() as Teacher));
            this.teachers = list;
            this.saveToLocalStorage();
            this.notify();
          }
          this.isSyncing = false;
          this.syncStatus = 'অনলাইন সিঙ্ক সম্পন্ন';
          this.notify();
        },
        handleSnapshotError('teachers')
      );

      onSnapshot(
        collection(db, 'notices'),
        (snap) => {
          if (!snap.empty) {
            const list: NoticeItem[] = [];
            snap.forEach((d) => list.push(d.data() as NoticeItem));
            this.notices = list;
            this.saveToLocalStorage();
            this.notify();
          }
          this.isSyncing = false;
          this.syncStatus = 'অনলাইন সিঙ্ক সম্পন্ন';
          this.notify();
        },
        handleSnapshotError('notices')
      );

      onSnapshot(
        collection(db, 'registrationRequests'),
        (snap) => {
          if (!snap.empty) {
            const list: RegistrationRequest[] = [];
            snap.forEach((d) => list.push(d.data() as RegistrationRequest));
            this.registrationRequests = list;
            this.saveToLocalStorage();
            this.notify();
          }
          this.isSyncing = false;
          this.syncStatus = 'অনলাইন সিঙ্ক সম্পন্ন';
          this.notify();
        },
        handleSnapshotError('registrationRequests')
      );

      onSnapshot(
        collection(db, 'pending_requests'),
        (snap) => {
          if (!snap.empty) {
            const list: RegistrationRequest[] = [];
            snap.forEach((d) => {
              const data = d.data();
              list.push({
                id: d.id,
                name: data.name || '',
                mobile: data.mobile || data.phone || '',
                phone: data.mobile || data.phone || '',
                email: data.email || '',
                role: data.role || 'Teacher',
                status: data.status || 'pending',
                date: data.date || '',
                feeDue: data.feeDue ?? 500,
                monthlyFee: data.monthlyFee ?? 200,
                feePaid: data.feePaid ?? false,
                createdAt: data.createdAt
              });
            });
            this.registrationRequests = list;
            this.saveToLocalStorage();
            this.notify();
          }
        },
        handleSnapshotError('pending_requests')
      );
    } catch (e) {
      console.warn('Firestore snapshot setup error:', e);
      this.isSyncing = false;
      this.syncStatus = 'স্থানীয় মোড সক্রিয়';
      this.notify();
    }
  }

  // --- LocalStorage Caching ---
  private saveToLocalStorage() {
    try {
      localStorage.setItem('madrasa_users', JSON.stringify(this.users));
      localStorage.setItem('madrasa_students', JSON.stringify(this.students));
      localStorage.setItem('madrasa_teachers', JSON.stringify(this.teachers));
      localStorage.setItem('madrasa_sobok', JSON.stringify(this.dailySobokList));
      localStorage.setItem('madrasa_history', JSON.stringify(this.sabakHistory));
      localStorage.setItem('madrasa_requests', JSON.stringify(this.registrationRequests));
      localStorage.setItem('madrasa_class_routine', JSON.stringify(this.classRoutines));
      localStorage.setItem('madrasa_kajer_routine', JSON.stringify(this.kajerRoutines));
      localStorage.setItem('madrasa_pora_progress', JSON.stringify(this.poraProgressList));
      localStorage.setItem('madrasa_attendance', JSON.stringify(this.attendanceList));
      localStorage.setItem('madrasa_fees', JSON.stringify(this.feeList));
      localStorage.setItem('madrasa_notices', JSON.stringify(this.notices));
      localStorage.setItem('madrasa_registrations', JSON.stringify(this.registrations));
      localStorage.setItem('madrasa_exams', JSON.stringify(this.examResults));
    } catch (e) {
      console.warn('LocalStorage save warning:', e);
    }
  }

  private loadFromLocalStorage() {
    try {
      const u = localStorage.getItem('madrasa_users');
      this.users = u ? JSON.parse(u) : [];

      const s = localStorage.getItem('madrasa_students');
      this.students = s ? JSON.parse(s) : INITIAL_STUDENTS;

      const t = localStorage.getItem('madrasa_teachers');
      this.teachers = t ? JSON.parse(t) : INITIAL_TEACHERS;

      const sb = localStorage.getItem('madrasa_sobok');
      this.dailySobokList = sb ? JSON.parse(sb) : [];

      const h = localStorage.getItem('madrasa_history');
      this.sabakHistory = h ? JSON.parse(h) : [];

      const rq = localStorage.getItem('madrasa_requests');
      this.registrationRequests = rq ? JSON.parse(rq) : [];

      const cr = localStorage.getItem('madrasa_class_routine');
      this.classRoutines = cr ? JSON.parse(cr) : INITIAL_CLASS_ROUTINES;

      const kr = localStorage.getItem('madrasa_kajer_routine');
      this.kajerRoutines = kr ? JSON.parse(kr) : INITIAL_KAJER_ROUTINES;

      const pp = localStorage.getItem('madrasa_pora_progress');
      this.poraProgressList = pp ? JSON.parse(pp) : [];

      const att = localStorage.getItem('madrasa_attendance');
      this.attendanceList = att ? JSON.parse(att) : [];

      const f = localStorage.getItem('madrasa_fees');
      this.feeList = f ? JSON.parse(f) : [];

      const n = localStorage.getItem('madrasa_notices');
      this.notices = n ? JSON.parse(n) : INITIAL_NOTICES;

      const rg = localStorage.getItem('madrasa_registrations');
      this.registrations = rg ? JSON.parse(rg) : [];

      const ex = localStorage.getItem('madrasa_exams');
      this.examResults = ex ? JSON.parse(ex) : [];
    } catch (e) {
      console.warn('LocalStorage load warning:', e);
    }
  }
}

export const repository = new MadrasaRepositoryService();
