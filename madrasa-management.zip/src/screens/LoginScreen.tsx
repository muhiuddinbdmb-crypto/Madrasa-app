import React, { useState } from 'react';
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  HelpCircle,
  UserPlus,
  CheckCircle2,
  CreditCard,
  AlertCircle,
  Download
} from 'lucide-react';
import { MadrasaLogo } from '../components/MadrasaLogo';
import { RegistrationRequest } from '../types';

interface LoginScreenProps {
  onLogin: (id: string, pass: string) => void;
  onSubmitRegistration: (req: RegistrationRequest) => void;
  errorMessage?: string | null;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLogin,
  onSubmitRegistration,
  errorMessage
}) => {
  const [identifier, setIdentifier] = useState('muhiuddin.bd.mb@gmail.com');
  const [password, setPassword] = useState('MS723926MS');
  const [showPassword, setShowPassword] = useState(false);
  const [showForgotModal, setShowForgotModal] = useState(false);

  // Registration Modal State (Issue 2 & Issue 3)
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const [showFeeDialog, setShowFeeDialog] = useState(false);
  const [snackBarMessage, setSnackBarMessage] = useState<string | null>(null);

  // Form Fields
  const [regName, setRegName] = useState('');
  const [regMobile, setRegMobile] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regRole, setRegRole] = useState<'Admin' | 'Teacher' | 'Guardian'>('Teacher');
  const [regError, setRegError] = useState('');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(identifier, password);
  };

  const handleOpenRegistration = () => {
    setRegError('');
    setShowRegistrationModal(true);
  };

  const handleRoleChange = (role: 'Admin' | 'Teacher' | 'Guardian') => {
    setRegRole(role);
    // Show fee info dialog when Admin / Other Madrasa or role is selected (Issue 3)
    if (role === 'Admin') {
      setShowFeeDialog(true);
    }
  };

  const handleRegistrationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regName.trim() || !regMobile.trim() || !regPassword.trim()) {
      setRegError('দয়া করে সকল বাধ্যতামূলক তথ্য পূরণ করুন।');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError('পাসওয়ার্ড এবং নিশ্চিত পাসওয়ার্ড মিলছে না!');
      return;
    }

    // Save to pending_requests collection (Issue 2 & 3)
    const newRequest: RegistrationRequest = {
      id: `req_${Date.now()}`,
      name: regName.trim(),
      mobile: regMobile.trim(),
      phone: regMobile.trim(),
      email: regEmail.trim(),
      password: regPassword.trim(),
      role: regRole,
      status: 'pending',
      date: new Date().toLocaleDateString('bn-BD'),
      feeDue: 500,
      monthlyFee: 200,
      feePaid: false,
      createdAt: new Date().toISOString()
    };

    onSubmitRegistration(newRequest);

    setShowRegistrationModal(false);
    setShowFeeDialog(false);
    setRegName('');
    setRegMobile('');
    setRegEmail('');
    setRegPassword('');
    setRegConfirmPassword('');

    // Show SnackBar required in Issue 2
    setSnackBarMessage('আপনার রেজিস্ট্রেশন রিকোয়েস্ট এডমিনের কাছে গেছে। এপ্রুভ হলে লগইন করতে পারবেন।');
    setTimeout(() => {
      setSnackBarMessage(null);
    }, 6000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#031A18] via-[#0A2E2B] to-[#0D3B36] flex flex-col items-center justify-center p-4 sm:p-6 text-slate-800 relative">
      {/* Toast / SnackBar for registration submission (Issue 2) */}
      {snackBarMessage && (
        <div className="fixed top-5 z-50 max-w-md w-[90%] mx-auto bg-emerald-900 border border-emerald-400 text-white p-4 rounded-2xl shadow-2xl flex items-start gap-3 animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm font-semibold leading-relaxed">
            {snackBarMessage}
          </div>
        </div>
      )}

      <div className="w-full max-w-md my-auto">
        {/* Top Logo & Title (Issue 1: Exact logo Image 1, 120x120 container, circle, gold border) */}
        <div className="text-center text-white mb-5 flex flex-col items-center">
          <div className="mb-3">
            <MadrasaLogo size={120} />
          </div>

          <h1 className="text-lg sm:text-xl font-bold leading-snug drop-shadow-sm max-w-sm">
            হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা
          </h1>
          <p className="text-amber-300 font-medium text-xs sm:text-sm mt-1">
            মাদ্রাসা ম্যানেজমেন্ট সিস্টেমে স্বাগতম
          </p>
        </div>

        {/* Login Box */}
        <div className="bg-white rounded-3xl p-6 shadow-2xl border border-slate-100">
          <h2 className="text-xl font-bold text-[#0A2E2B] text-center mb-5 flex items-center justify-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-700" />
            লগইন করুন
          </h2>

          {errorMessage && (
            <div className="bg-red-50 text-red-700 border border-red-200 text-xs sm:text-sm rounded-xl p-3 mb-4 font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                ইমেইল অথবা মোবাইল নম্বর
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="মোবাইল বা ইমেইল লিখুন"
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:bg-white transition-all text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                পাসওয়ার্ড
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="পাসওয়ার্ড দিন"
                  className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:bg-white transition-all text-slate-800"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600 focus:outline-none"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 px-4 rounded-xl font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 transition-colors shadow-md text-base mt-2 active:scale-98"
            >
              প্রবেশ করুন
            </button>
          </form>

          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => setShowForgotModal(true)}
              className="text-xs text-slate-500 hover:text-emerald-800 font-medium inline-flex items-center gap-1"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              পাসওয়ার্ড ভুলে গেছেন?
            </button>
          </div>
        </div>

        {/* ISSUE 2: Button text MUST BE ONLY "Registration" (রেজিস্ট্রেশন) */}
        <div className="mt-4">
          <button
            type="button"
            onClick={handleOpenRegistration}
            className="w-full py-3.5 px-4 rounded-2xl font-bold text-white bg-white/10 hover:bg-white/20 border border-amber-400/60 backdrop-blur-sm transition-all flex items-center justify-center gap-2 text-sm shadow-sm active:scale-98"
          >
            <UserPlus className="w-4 h-4 text-amber-300" />
            Registration
          </button>
        </div>

        {/* Download Flutter Project ZIP */}
        <div className="mt-3 text-center">
          <a
            href="/madrasa_management_flutter.zip"
            download="madrasa_management_flutter.zip"
            className="inline-flex items-center gap-2 text-xs font-semibold text-amber-300 hover:text-amber-200 transition-colors py-1.5 px-3 rounded-full bg-white/5 border border-amber-300/30"
          >
            <Download className="w-3.5 h-3.5" />
            সম্পূর্ণ ফ্লাটার প্রজেক্ট জিপ ডাউনলোড করুন (Download Flutter ZIP)
          </a>
        </div>

        {/* Main Admin Info Box */}
        <div className="mt-4 p-3.5 rounded-2xl bg-black/40 backdrop-blur-sm border border-emerald-500/20 text-center text-white">
          <p className="text-amber-300 font-bold text-xs">
            প্রধান পরিচালক: MD Muhi Uddin
          </p>
          <p className="text-[11px] text-emerald-100/80 mt-0.5">
            মোবাইল: 01715047342 | ইমেইল: muhiuddin.bd.mb@gmail.com
          </p>
        </div>
      </div>

      {/* ISSUE 2: Registration Form Modal */}
      {showRegistrationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 max-h-[92vh] overflow-y-auto my-auto text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-lg font-bold text-[#0A2E2B] flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-700" />
                নতুন রেজিস্ট্রেশন ফর্ম
              </h3>
              <button
                onClick={() => setShowRegistrationModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            {regError && (
              <div className="bg-red-50 text-red-700 text-xs font-semibold p-2.5 rounded-xl mb-3 border border-red-200">
                {regError}
              </div>
            )}

            <form onSubmit={handleRegistrationSubmit} className="space-y-3">
              {/* Full Name in Bangla */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  পূর্ণ নাম (বাংলায়) *
                </label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="যেমন: হাফেজ কারী আব্দুল্লাহ"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              {/* Mobile Number */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  মোবাইল নম্বর *
                </label>
                <input
                  type="tel"
                  required
                  value={regMobile}
                  onChange={(e) => setRegMobile(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none font-mono"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ইমেইল এড্রেস
                </label>
                <input
                  type="email"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  পাসওয়ার্ড *
                </label>
                <input
                  type="password"
                  required
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  placeholder="কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  পাসওয়ার্ড নিশ্চিত করুন *
                </label>
                <input
                  type="password"
                  required
                  value={regConfirmPassword}
                  onChange={(e) => setRegConfirmPassword(e.target.value)}
                  placeholder="পুনরায় একই পাসওয়ার্ড দিন"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              {/* Dropdown: Select Role -> Admin, Teacher, Guardian */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select Role (পদবী নির্বাচন) *
                </label>
                <select
                  value={regRole}
                  onChange={(e) =>
                    handleRoleChange(e.target.value as 'Admin' | 'Teacher' | 'Guardian')
                  }
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-emerald-950 focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                >
                  <option value="Admin">Admin (অন্যান্য মাদ্রাসা এডমিন / Admin for other madrasa)</option>
                  <option value="Teacher">Teacher (শিক্ষক)</option>
                  <option value="Guardian">Guardian (অভিভাবক)</option>
                </select>

                {/* Show fees ONLY for Admin role (First registration 500tk + Monthly 200tk) */}
                {regRole === 'Admin' && (
                  <div className="mt-2 p-3 bg-amber-50 rounded-xl border border-amber-300 text-xs text-amber-900">
                    <div className="font-bold flex items-center justify-between mb-1">
                      <span className="flex items-center gap-1.5 text-amber-800">
                        <CreditCard className="w-3.5 h-3.5" />
                        অন্য মাদ্রাসা রেজিস্ট্রেশন ফি
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowFeeDialog(true)}
                        className="text-[10px] font-bold text-amber-700 underline"
                      >
                        বিস্তারিত
                      </button>
                    </div>
                    <div className="space-y-0.5 text-[11px] font-semibold text-amber-950">
                      <div>• ১ম রেজিস্ট্রেশন ফি: ৫০০ টাকা</div>
                      <div>• মাসিক ফি: ২০০ টাকা</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Notice note */}
              <div className="bg-amber-50/80 p-3 rounded-xl border border-amber-200/80 text-[11px] text-amber-900 leading-relaxed">
                রেজিস্ট্রেশন সাবমিট করার পর রিকোয়েস্ট প্রধান এডমিনের কাছে অনুমোদনের জন্য যাবে। অনুমোদন সম্পন্ন হলে এই পাসওয়ার্ড দিয়ে লগইন করতে পারবেন।
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRegistrationModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  রিকোয়েস্ট পাঠান
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ISSUE 3: Other Madrasa Fee Dialog */}
      {showFeeDialog && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-amber-300 text-slate-800 text-center animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 mx-auto flex items-center justify-center mb-3">
              <CreditCard className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-bold text-[#0A2E2B] mb-2">
              অন্য মাদ্রাসা রেজিস্ট্রেশন ফি
            </h3>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left text-xs sm:text-sm text-slate-700 space-y-1.5 my-3">
              <p className="font-semibold text-slate-900 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
                • ১ম রেজিস্ট্রেশন ফি: ৫০০ টাকা
              </p>
              <p className="font-semibold text-slate-900 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-600 inline-block" />
                • মাসিক ফি: ২০০ টাকা
              </p>
            </div>

            <div className="space-y-2 mt-4">
              <button
                type="button"
                onClick={() => {
                  alert('bKash/Nagad পেমেন্ট গেটওয়ে শীঘ্রই যুক্ত হচ্ছে। অনুগ্রহ করে "Request to Admin" চাপুন।');
                }}
                className="w-full py-2.5 rounded-xl font-bold text-xs bg-amber-500 hover:bg-amber-600 text-white shadow-xs"
              >
                Pay Now (bKash/Nagad - Coming Soon)
              </button>

              <button
                type="button"
                onClick={() => setShowFeeDialog(false)}
                className="w-full py-2.5 rounded-xl font-bold text-xs bg-emerald-800 hover:bg-emerald-900 text-white shadow-xs"
              >
                Request to Admin
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full text-slate-800 shadow-2xl border border-slate-100 text-center">
            <HelpCircle className="w-12 h-12 text-emerald-800 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-2">পাসওয়ার্ড পুনরুদ্ধার</h3>
            <p className="text-sm text-slate-600 mb-4 leading-relaxed">
              পাসওয়ার্ড ভুলে গেলে অনুগ্রহ করে প্রধান এডমিনের সাথে যোগাযোগ করুন:
            </p>
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-700 font-semibold mb-5">
              <p>মোবাইল: 01715047342</p>
              <p className="mt-1">ইমেইল: muhiuddin.bd.mb@gmail.com</p>
            </div>
            <button
              onClick={() => setShowForgotModal(false)}
              className="w-full py-2.5 rounded-xl bg-emerald-800 text-white font-bold text-sm"
            >
              ঠিক আছে
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
