import React from 'react';
import {
  ArrowLeft,
  Building,
  Check,
  Ban,
  Phone,
  Mail,
  MapPin,
  Calendar
} from 'lucide-react';
import { MadrasaRegistration } from '../types';

interface OtherMadrasaApprovalsScreenProps {
  registrations: MadrasaRegistration[];
  onUpdateStatus: (id: string, status: 'APPROVED' | 'BLOCKED') => void;
  onBack: () => void;
}

export const OtherMadrasaApprovalsScreen: React.FC<OtherMadrasaApprovalsScreenProps> = ({
  registrations,
  onUpdateStatus,
  onBack
}) => {
  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">অন্যান্য মাদ্রাসা অনুমোদন</h1>
            <p className="text-xs text-amber-300">নিবন্ধিত মাদ্রাসার তালিকা</p>
          </div>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4">
        {/* Info Banner */}
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-3.5 mb-4 text-xs text-amber-950">
          <p className="font-bold">সফটওয়্যার এক্টিভেশন নীতি:</p>
          <p className="mt-0.5">
            অন্যান্য মাদ্রাসা আবেদন করার পর তাদের পেমেন্ট (বিকাশ 01715047342) নিশ্চিত করে অনুমোদন করুন।
          </p>
        </div>

        {registrations.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <Building className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো অন্যান্য মাদ্রাসার রেজিস্ট্রেশন পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3.5">
            {registrations.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between gap-3 mb-2 pb-2 border-b border-slate-100">
                  <div>
                    <h3 className="font-bold text-base text-slate-900 leading-tight">
                      {item.madrasaName}
                    </h3>
                    <p className="text-xs text-emerald-800 font-semibold mt-0.5">
                      পরিচালক: {item.adminName}
                    </p>
                  </div>

                  <span
                    className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                      item.status === 'APPROVED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'BLOCKED'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.status === 'APPROVED'
                      ? 'অনুমোদিত'
                      : item.status === 'BLOCKED'
                      ? 'ব্লক করা'
                      : 'অপেক্ষমাণ'}
                  </span>
                </div>

                <div className="space-y-1 text-xs text-slate-600 mb-3">
                  {item.address && (
                    <p className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{item.address}</span>
                    </p>
                  )}
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-semibold text-slate-800 font-mono">{item.phone}</span>
                  </p>
                  {item.email && (
                    <p className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{item.email}</span>
                    </p>
                  )}
                  <p className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                    <Calendar className="w-3.5 h-3.5 shrink-0" />
                    <span>তারিখ: {item.registeredDate}</span>
                  </p>
                </div>

                {/* Approve / Block Actions */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                  {item.status !== 'APPROVED' && (
                    <button
                      onClick={() => onUpdateStatus(item.id, 'APPROVED')}
                      className="flex-1 py-2 px-3 rounded-xl bg-[#2E7D32] hover:bg-emerald-800 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                    >
                      <Check className="w-3.5 h-3.5" />
                      অনুমোদন করুন
                    </button>
                  )}

                  {item.status !== 'BLOCKED' && (
                    <button
                      onClick={() => onUpdateStatus(item.id, 'BLOCKED')}
                      className="flex-1 py-2 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      ব্লক করুন
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
