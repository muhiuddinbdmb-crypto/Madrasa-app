import React, { useEffect } from 'react';
import { MadrasaLogo } from '../components/MadrasaLogo';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 1800);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#031A18] via-[#0A2E2B] to-[#0D3B36] flex flex-col items-center justify-center p-6 text-white text-center">
      {/* Islamic Emblem / Logo: size 120 with #D4AF37 border */}
      <div className="mb-5 animate-pulse">
        <MadrasaLogo size={120} />
      </div>

      <h1 className="text-xl sm:text-2xl font-extrabold max-w-sm leading-snug drop-shadow-md">
        হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা
      </h1>

      <p className="text-amber-300 font-semibold text-sm mt-2">
        স্থাপিত: ২০১৩ খ্রিষ্টাব্দ
      </p>

      <div className="mt-8 flex flex-col items-center gap-2">
        <div className="w-8 h-8 border-3 border-amber-400 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs text-emerald-200/80 font-medium tracking-wider">লোড হচ্ছে...</span>
      </div>
    </div>
  );
};
