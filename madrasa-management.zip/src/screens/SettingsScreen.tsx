import React, { useState } from 'react';
import {
  ArrowLeft,
  User,
  ShieldAlert,
  Building,
  Key,
  LogOut,
  ChevronRight,
  Lock,
  Phone,
  Mail,
  ShieldCheck,
  Building2,
  Download
} from 'lucide-react';
import { ScreenType, UserAccount } from '../types';

interface SettingsScreenProps {
  currentUser: UserAccount | null;
  isAppLockEnabled: boolean;
  onToggleAppLock: (enabled: boolean) => void;
  onChangePassword: (newPass: string) => void;
  onNavigate: (screen: ScreenType) => void;
  onLogout: () => void;
  onBack: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  currentUser,
  isAppLockEnabled,
  onToggleAppLock,
  onChangePassword,
  onNavigate,
  onLogout,
  onBack
}) => {
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  const isMainAdmin = currentUser?.isMain === true;

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword.trim()) return;
    onChangePassword(newPassword.trim());
    setShowPasswordModal(false);
    setNewPassword('');
    setShowSuccessToast(true);
    setTimeout(() => setShowSuccessToast(false), 3000);
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">সেটিংস ও মেনু</h1>
            <p className="text-xs text-amber-300">প্রোফাইল ও কনফিগারেশন</p>
          </div>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4 space-y-4">
        {/* Success Toast */}
        {showSuccessToast && (
          <div className="bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs text-center animate-in fade-in">
            পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!
          </div>
        )}

        {/* User Profile Card */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-[#0A2E2B] text-amber-400 flex items-center justify-center font-extrabold shadow-sm text-lg">
            <User className="w-7 h-7" />
          </div>

          <div className="flex-1 min-w-0">
            <h2 className="text-base font-bold text-slate-900 truncate">
              {currentUser?.name || 'ব্যবহারকারী'}
            </h2>
            <div className="flex items-center gap-2 mt-0.5">
              <span
                className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                  isMainAdmin
                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {isMainAdmin ? 'প্রধান পরিচালক (Main Admin)' : `রোল: ${currentUser?.role || 'ইউজার'}`}
              </span>
            </div>
            <p className="text-xs text-slate-500 flex items-center gap-1 mt-1 font-mono">
              <Phone className="w-3 h-3 text-slate-400" />
              {currentUser?.phone || '01715047342'}
            </p>
          </div>
        </div>

        {/* Admin Management Section (Main Admin only) */}
        {isMainAdmin && (
          <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
            <div className="bg-slate-50 px-4 py-2 border-b border-slate-100 text-xs font-bold text-slate-500 uppercase tracking-wider">
              প্রধান পরিচালক এক্সেস
            </div>

            <div className="divide-y divide-slate-100">
              <button
                onClick={() => onNavigate('adminManagement')}
                className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">এডমিন ব্যবস্থাপনা</h4>
                    <p className="text-xs text-slate-500">২য় এডমিন যোগ ও বাদ দেওয়া</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>

              <button
                onClick={() => onNavigate('otherMadrasaApprovals')}
                className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">অন্যান্য মাদ্রাসা অনুমোদন</h4>
                    <p className="text-xs text-slate-500">নিবন্ধন তালিকা ও অনুমোদন</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>
            </div>
          </div>
        )}

        {/* General Settings */}
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
          <div className="bg-slate-50 px-4 py-2 border-b border-slate-100 text-xs font-bold text-slate-500 uppercase tracking-wider">
            সাধারণ সেটিংস
          </div>

          <div className="divide-y divide-slate-100">
            {/* App Lock */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">অ্যাপ লক পিন</h4>
                  <p className="text-xs text-slate-500">অ্যাপ ওপেনে পিন কোড সুরক্ষা</p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={isAppLockEnabled}
                onChange={(e) => onToggleAppLock(e.target.checked)}
                className="w-5 h-5 accent-emerald-700 rounded cursor-pointer"
              />
            </div>

            {/* Change Password */}
            <button
              onClick={() => setShowPasswordModal(true)}
              className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">পাসওয়ার্ড পরিবর্তন</h4>
                  <p className="text-xs text-slate-500">লগইন পাসওয়ার্ড আপডেট করুন</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400" />
            </button>

            {/* Download Flutter Project ZIP */}
            <a
              href="/madrasa_management_flutter.zip"
              download="madrasa_management_flutter.zip"
              className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-50 transition-colors block text-inherit"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">ফ্লাটার প্রজেক্ট জিপ ডাউনলোড</h4>
                  <p className="text-xs text-slate-500">সম্পূর্ণ সোর্স কোড ও অ্যান্ড্রয়েড কনফিগারেশন</p>
                </div>
              </div>
              <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-full">
                ZIP
              </span>
            </a>

            {/* Madrasa Info */}
            <div className="p-4 flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                <Building className="w-5 h-5" />
              </div>
              <div className="text-xs text-slate-600 leading-relaxed">
                <h4 className="font-bold text-sm text-slate-900">মাদ্রাসার ঠিকানা</h4>
                <p className="mt-0.5">হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা</p>
                <p>স্থাপিত: ২০১৩ খ্রিষ্টাব্দ</p>
              </div>
            </div>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={onLogout}
          className="w-full py-3.5 px-4 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-colors active:scale-98"
        >
          <LogOut className="w-4 h-4" />
          লগআউট করুন
        </button>
      </div>

      {/* Change Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-100">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <Key className="w-5 h-5 text-emerald-700" />
              নতুন পাসওয়ার্ড লিখুন
            </h3>

            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  নতুন পাসওয়ার্ড *
                </label>
                <input
                  type="text"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="কমপক্ষে ৬ ডিজিটের পাসওয়ার্ড"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  আপডেট করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
