import React, { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  Trash2,
  Phone,
  Mail,
  GraduationCap,
  UserCheck
} from 'lucide-react';
import { Teacher } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';

interface TeacherScreenProps {
  teachers: Teacher[];
  isAdmin: boolean;
  onAddTeacher: (teacher: Teacher, pass: string) => void;
  onDeleteTeacher: (id: string) => void;
  onBack: () => void;
}

export const TeacherScreen: React.FC<TeacherScreenProps> = ({
  teachers,
  isAdmin,
  onAddTeacher,
  onDeleteTeacher,
  onBack
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [teacherToDelete, setTeacherToDelete] = useState<Teacher | null>(null);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [designation, setDesignation] = useState('সহকারী শিক্ষক');
  const [classAssigned, setClassAssigned] = useState('হিফজুল কুরআন');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('123456');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    onAddTeacher(
      {
        id: `tc_${Date.now()}`,
        name: name.trim(),
        phone: phone.trim(),
        designation: designation.trim(),
        classAssigned: classAssigned.trim(),
        email: email.trim()
      },
      password.trim() || '123456'
    );

    setShowAddModal(false);
    setName('');
    setPhone('');
    setEmail('');
    setPassword('123456');
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">শিক্ষকগণের তালিকা</h1>
            <p className="text-xs text-amber-300">মোট: {teachers.length} জন</p>
          </div>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            নতুন শিক্ষক
          </button>
        )}
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4">
        {teachers.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <GraduationCap className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো শিক্ষকের তথ্য পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3">
            {teachers.map((tc) => (
              <div
                key={tc.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 flex items-center justify-between gap-3 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-full bg-orange-100 text-orange-600 font-bold flex items-center justify-center shrink-0">
                    <UserCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-slate-900 leading-tight">
                      {tc.name}
                    </h3>
                    <p className="text-xs font-semibold text-emerald-800 mt-0.5">
                      {tc.designation} {tc.classAssigned && `• ${tc.classAssigned}`}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                      <span className="flex items-center gap-1 font-mono">
                        <Phone className="w-3 h-3" />
                        {tc.phone}
                      </span>
                      {tc.email && (
                        <span className="flex items-center gap-1 truncate max-w-[140px]">
                          <Mail className="w-3 h-3" />
                          {tc.email}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {isAdmin && (
                  <button
                    onClick={() => setTeacherToDelete(tc)}
                    className="p-2 rounded-xl text-red-500 hover:bg-red-50 transition-colors shrink-0"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Teacher Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-emerald-700" />
              নতুন শিক্ষক যুক্ত করুন
            </h3>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  শিক্ষকের পুরো নাম *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="যেমন: মাওলানা আব্দুর রহমান"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  মোবাইল নম্বর *
                </label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">পদবী</label>
                  <input
                    type="text"
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    দায়িত্বপ্রাপ্ত শ্রেণী
                  </label>
                  <input
                    type="text"
                    value={classAssigned}
                    onChange={(e) => setClassAssigned(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ইমেইল</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ইমেইল এড্রেস"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  লগইন পাসওয়ার্ড (ডিফল্ট: 123456)
                </label>
                <input
                  type="text"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal (Point 1) */}
      <ConfirmModal
        isOpen={teacherToDelete !== null}
        title="শিক্ষককে মুছে ফেলবেন?"
        message={`আপনি কি নিশ্চিত যে শিক্ষক "${teacherToDelete?.name}"-কে তালিকা থেকে মুছে ফেলতে চান?`}
        confirmLabel="মুছে ফেলুন"
        cancelLabel="বাতিল"
        onConfirm={() => {
          if (teacherToDelete) {
            onDeleteTeacher(teacherToDelete.id);
            setTeacherToDelete(null);
          }
        }}
        onCancel={() => setTeacherToDelete(null)}
      />
    </div>
  );
};
