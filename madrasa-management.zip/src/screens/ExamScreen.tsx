import React, { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  Award,
  BookOpen
} from 'lucide-react';
import { ExamResult, Student } from '../types';

interface ExamScreenProps {
  examResults: ExamResult[];
  students: Student[];
  isAdmin: boolean;
  onAddResult: (res: ExamResult) => void;
  onBack: () => void;
}

export const ExamScreen: React.FC<ExamScreenProps> = ({
  examResults,
  students,
  isAdmin,
  onAddResult,
  onBack
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    students[0]?.id || ''
  );
  const [examName, setExamName] = useState('মাসিক মূল্যায়ন পরীক্ষা');
  const [subject, setSubject] = useState('কুরআনুল কারীম হিফজ');
  const [marks, setMarks] = useState('৯৫');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const st = students.find((s) => s.id === selectedStudentId);
    if (!st) return;

    const m = parseInt(marks, 10) || 0;
    const grade =
      m >= 80 ? 'A+' : m >= 70 ? 'A' : m >= 60 ? 'A-' : m >= 50 ? 'B' : m >= 40 ? 'C' : 'F';

    onAddResult({
      id: `ex_${Date.now()}`,
      examName,
      studentName: st.name,
      studentRoll: st.roll,
      subject,
      totalMarks: 100,
      obtainedMarks: m,
      grade
    });

    setShowAddModal(false);
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">পরীক্ষার ফলাফল</h1>
            <p className="text-xs text-amber-300">মূল্যায়ন ও গ্রেড বিবরণী</p>
          </div>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            ফলাফল যোগ
          </button>
        )}
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4">
        {examResults.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <Award className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো পরীক্ষার ফলাফল পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3">
            {examResults.map((ex) => (
              <div
                key={ex.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 flex items-center justify-between gap-3 hover:shadow-md transition-shadow"
              >
                <div>
                  <h4 className="font-bold text-sm text-slate-900 leading-tight">
                    {ex.studentName} <span className="text-xs text-slate-500">(রোল: {ex.studentRoll})</span>
                  </h4>
                  <p className="text-xs text-emerald-800 font-semibold mt-0.5">
                    {ex.examName} • {ex.subject}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    প্রাপ্ত নম্বর: <span className="font-bold text-slate-900">{ex.obtainedMarks}</span> / {ex.totalMarks}
                  </p>
                </div>

                <div
                  className={`px-3 py-1.5 rounded-xl font-extrabold text-sm ${
                    ex.grade === 'A+'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : ex.grade === 'A'
                      ? 'bg-blue-100 text-blue-800'
                      : ex.grade === 'F'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {ex.grade}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Exam Result Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <Award className="w-5 h-5 text-emerald-700" />
              নতুন পরীক্ষার ফলাফল যুক্ত করুন
            </h3>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ছাত্র নির্বাচন *</label>
                <select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      রোল {s.roll}: {s.name} ({s.className})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">পরীক্ষার নাম *</label>
                <input
                  type="text"
                  required
                  value={examName}
                  onChange={(e) => setExamName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">বিষয় *</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">প্রাপ্ত নম্বর (১০০ এর মধ্যে) *</label>
                <input
                  type="number"
                  required
                  max="100"
                  min="0"
                  value={marks}
                  onChange={(e) => setMarks(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
