import React, { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  Trash2,
  Calendar,
  Clock,
  BookOpen
} from 'lucide-react';
import { ClassRoutineItem, KajerRoutineItem } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';

interface RoutineScreenProps {
  classRoutines: ClassRoutineItem[];
  kajerRoutines: KajerRoutineItem[];
  isAdmin: boolean;
  isTeacher: boolean;
  isGuardian: boolean;
  onAddClassRoutine: (item: ClassRoutineItem) => void;
  onDeleteClassRoutine: (id: string) => void;
  onAddKajerRoutine: (item: KajerRoutineItem) => void;
  onUpdateKajerStatus: (id: string, status: string) => void;
  onDeleteKajerRoutine: (id: string) => void;
  onBack: () => void;
}

export const RoutineScreen: React.FC<RoutineScreenProps> = ({
  classRoutines,
  kajerRoutines,
  isAdmin,
  isTeacher,
  isGuardian,
  onAddClassRoutine,
  onDeleteClassRoutine,
  onAddKajerRoutine,
  onUpdateKajerStatus,
  onDeleteKajerRoutine,
  onBack
}) => {
  const [selectedTab, setSelectedTab] = useState<'class' | 'kajer'>('class');
  const [showAddClassModal, setShowAddClassModal] = useState(false);
  const [showAddKajerModal, setShowAddKajerModal] = useState(false);

  const [classToDelete, setClassToDelete] = useState<string | null>(null);
  const [kajerToDelete, setKajerToDelete] = useState<string | null>(null);

  // New Class Routine Form State
  const [cDay, setCDay] = useState('শনিবার');
  const [cTime, setCTime] = useState('০৭:০০ - ০৮:০০ AM');
  const [cClass, setCClass] = useState('হিফজুল কুরআন');
  const [cSubject, setCSubject] = useState('');
  const [cTeacher, setCTeacher] = useState('');

  // New Kajer Routine Form State
  const [kTask, setKTask] = useState('');
  const [kTime, setKTime] = useState('');
  const [kPerson, setKPerson] = useState('');

  const handleAddClassSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cSubject.trim()) return;
    onAddClassRoutine({
      id: `cr_${Date.now()}`,
      day: cDay,
      time: cTime,
      className: cClass,
      subject: cSubject.trim(),
      teacherName: cTeacher.trim()
    });
    setShowAddClassModal(false);
    setCSubject('');
    setCTeacher('');
  };

  const handleAddKajerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!kTask.trim()) return;
    onAddKajerRoutine({
      id: `kr_${Date.now()}`,
      taskName: kTask.trim(),
      time: kTime.trim(),
      assignedPerson: kPerson.trim(),
      status: 'অপেক্ষমাণ'
    });
    setShowAddKajerModal(false);
    setKTask('');
    setKTime('');
    setKPerson('');
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-base font-bold">মাদ্রাসার রুটিন ব্যবস্থাপনা</h1>
        </div>

        {selectedTab === 'class' && isAdmin && (
          <button
            onClick={() => setShowAddClassModal(true)}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            ক্লাস রুটিন
          </button>
        )}

        {selectedTab === 'kajer' && (isAdmin || isTeacher) && (
          <button
            onClick={() => setShowAddKajerModal(true)}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            কাজের রুটিন
          </button>
        )}
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-4">
        {/* Tab Switcher (Guardian only sees Class Routine) */}
        {!isGuardian && (
          <div className="bg-white rounded-2xl p-1.5 shadow-xs border border-slate-200 flex mb-4">
            <button
              onClick={() => setSelectedTab('class')}
              className={`flex-1 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 ${
                selectedTab === 'class'
                  ? 'bg-[#0A2E2B] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-4 h-4" />
              ক্লাস রুটিন
            </button>
            <button
              onClick={() => setSelectedTab('kajer')}
              className={`flex-1 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 ${
                selectedTab === 'kajer'
                  ? 'bg-[#0A2E2B] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-4 h-4" />
              কাজের রুটিন
            </button>
          </div>
        )}

        {/* Content: Class Routine */}
        {selectedTab === 'class' && (
          <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#0A2E2B] text-[#D4AF37] text-xs font-bold uppercase tracking-wider">
                    <th className="py-3 px-4">বার (দিন)</th>
                    <th className="py-3 px-4">সময়সূচী</th>
                    <th className="py-3 px-4">শ্রেণী</th>
                    <th className="py-3 px-4">বিষয়</th>
                    <th className="py-3 px-4">শিক্ষক</th>
                    {isAdmin && <th className="py-3 px-3 text-center w-16">অ্যাকশন</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
                  {classRoutines.length === 0 ? (
                    <tr>
                      <td colSpan={isAdmin ? 6 : 5} className="py-12 text-center text-slate-400">
                        কোনো ক্লাস রুটিন যুক্ত করা হয়নি
                      </td>
                    </tr>
                  ) : (
                    classRoutines.map((cr) => (
                      <tr key={cr.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-bold text-emerald-950">{cr.day}</td>
                        <td className="py-3 px-4 text-slate-600 font-medium">{cr.time}</td>
                        <td className="py-3 px-4 text-slate-700">{cr.className}</td>
                        <td className="py-3 px-4 font-semibold text-slate-900">{cr.subject}</td>
                        <td className="py-3 px-4 text-slate-600">{cr.teacherName || '-'}</td>
                        {isAdmin && (
                          <td className="py-3 px-3 text-center">
                            <button
                              onClick={() => setClassToDelete(cr.id)}
                              className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
                              title="মুছে ফেলুন"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Content: Kajer Routine */}
        {selectedTab === 'kajer' && (
          <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#0A2E2B] text-[#D4AF37] text-xs font-bold uppercase tracking-wider">
                    <th className="py-3 px-4">কাজের বিবরণ</th>
                    <th className="py-3 px-4">সময়</th>
                    <th className="py-3 px-4">দায়িত্বপ্রাপ্ত</th>
                    <th className="py-3 px-4 text-center">স্ট্যাটাস (ক্লিক করে পরিবর্তন)</th>
                    {(isAdmin || isTeacher) && (
                      <th className="py-3 px-3 text-center w-16">অ্যাকশন</th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
                  {kajerRoutines.length === 0 ? (
                    <tr>
                      <td colSpan={isAdmin || isTeacher ? 5 : 4} className="py-12 text-center text-slate-400">
                        কোনো কাজের রুটিন যুক্ত করা হয়নি
                      </td>
                    </tr>
                  ) : (
                    kajerRoutines.map((kr) => {
                      const nextStatus =
                        kr.status === 'সম্পন্ন'
                          ? 'চলমান'
                          : kr.status === 'চলমান'
                          ? 'অপেক্ষমাণ'
                          : 'সম্পন্ন';

                      return (
                        <tr key={kr.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-4 font-bold text-emerald-950">{kr.taskName}</td>
                          <td className="py-3 px-4 text-slate-600 font-medium">{kr.time}</td>
                          <td className="py-3 px-4 text-slate-700 font-semibold">{kr.assignedPerson}</td>
                          <td className="py-3 px-4 text-center">
                            <button
                              disabled={!isAdmin && !isTeacher}
                              onClick={() => onUpdateKajerStatus(kr.id, nextStatus)}
                              className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                                kr.status === 'সম্পন্ন'
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                  : kr.status === 'চলমান'
                                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                  : 'bg-red-100 text-red-700 border border-red-300'
                              } ${isAdmin || isTeacher ? 'cursor-pointer hover:opacity-80 active:scale-95' : ''}`}
                            >
                              {kr.status}
                            </button>
                          </td>
                          {(isAdmin || isTeacher) && (
                            <td className="py-3 px-3 text-center">
                              <button
                                onClick={() => setKajerToDelete(kr.id)}
                                className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
                                title="মুছে ফেলুন"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          )}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Add Class Routine Modal */}
      {showAddClassModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-700" />
              নতুন ক্লাস রুটিন যুক্ত করুন
            </h3>

            <form onSubmit={handleAddClassSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">বার / দিন</label>
                <input
                  type="text"
                  required
                  value={cDay}
                  onChange={(e) => setCDay(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">সময়</label>
                <input
                  type="text"
                  required
                  value={cTime}
                  onChange={(e) => setCTime(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">শ্রেণী</label>
                <input
                  type="text"
                  value={cClass}
                  onChange={(e) => setCClass(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">বিষয় *</label>
                <input
                  type="text"
                  required
                  value={cSubject}
                  onChange={(e) => setCSubject(e.target.value)}
                  placeholder="যেমন: নতুন সবক / কিরাত"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">দায়িত্বপ্রাপ্ত শিক্ষক</label>
                <input
                  type="text"
                  value={cTeacher}
                  onChange={(e) => setCTeacher(e.target.value)}
                  placeholder="শিক্ষকের নাম"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddClassModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Kajer Routine Modal */}
      {showAddKajerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-emerald-700" />
              নতুন কাজের রুটিন যুক্ত করুন
            </h3>

            <form onSubmit={handleAddKajerSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">কাজের নাম / বিবরণ *</label>
                <input
                  type="text"
                  required
                  value={kTask}
                  onChange={(e) => setKTask(e.target.value)}
                  placeholder="যেমন: তাহাজ্জুদ ও ফজরের ঘুম থেকে জাগানো"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">সময়</label>
                <input
                  type="text"
                  value={kTime}
                  onChange={(e) => setKTime(e.target.value)}
                  placeholder="যেমন: ০৪:৩০ AM"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">দায়িত্বপ্রাপ্ত ব্যক্তি</label>
                <input
                  type="text"
                  value={kPerson}
                  onChange={(e) => setKPerson(e.target.value)}
                  placeholder="যেমন: হাফেজ মুশতাক"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddKajerModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Class Routine Delete */}
      <ConfirmModal
        isOpen={classToDelete !== null}
        title="ক্লাস রুটিন মুছে ফেলবেন?"
        message="আপনি কি নিশ্চিত যে এই ক্লাস রুটিনটি মুছে ফেলতে চান?"
        onConfirm={() => {
          if (classToDelete) {
            onDeleteClassRoutine(classToDelete);
            setClassToDelete(null);
          }
        }}
        onCancel={() => setClassToDelete(null)}
      />

      {/* Confirmation Modal for Kajer Routine Delete */}
      <ConfirmModal
        isOpen={kajerToDelete !== null}
        title="কাজের রুটিন মুছে ফেলবেন?"
        message="আপনি কি নিশ্চিত যে এই কাজের রুটিনটি মুছে ফেলতে চান?"
        onConfirm={() => {
          if (kajerToDelete) {
            onDeleteKajerRoutine(kajerToDelete);
            setKajerToDelete(null);
          }
        }}
        onCancel={() => setKajerToDelete(null)}
      />
    </div>
  );
};
