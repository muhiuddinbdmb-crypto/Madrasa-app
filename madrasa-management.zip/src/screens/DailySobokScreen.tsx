import React, { useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Search,
  Check,
  UserCheck
} from 'lucide-react';
import { DailySobokItem, UserAccount } from '../types';

interface DailySobokScreenProps {
  sobokList: DailySobokItem[];
  currentUser: UserAccount | null;
  onMarkCompleted: (
    itemId: string,
    sabakType: string,
    para: string,
    page: string,
    teacherName: string
  ) => void;
  onStudentClick: (studentId: string) => void;
  onBack: () => void;
}

export const DailySobokScreen: React.FC<DailySobokScreenProps> = ({
  sobokList,
  currentUser,
  onMarkCompleted,
  onStudentClick,
  onBack
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'সব' | 'বাকি' | 'শেষ'>('সব');

  const allThreeTypes = ['সবক', 'সাত সবক', 'আম্মোক্তা'];
  const total = sobokList.length;
  // All 3 completed = সবক শেষ, otherwise সবক বাকি
  const completedCount = sobokList.filter((item) =>
    allThreeTypes.every((t) => item.completedSabaks.includes(t))
  ).length;
  const remainingCount = Math.max(0, total - completedCount);

  const filteredList = sobokList
    .filter((item) => {
      const matchesSearch =
        item.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.studentRoll.toString().includes(searchQuery);

      const isAllDone = allThreeTypes.every((t) => item.completedSabaks.includes(t));
      const matchesFilter =
        filterStatus === 'সব'
          ? true
          : filterStatus === 'বাকি'
          ? !isAllDone
          : isAllDone;

      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      const aDone = allThreeTypes.every((t) => a.completedSabaks.includes(t));
      const bDone = allThreeTypes.every((t) => b.completedSabaks.includes(t));
      if (aDone === bDone) {
        return a.studentRoll - b.studentRoll;
      }
      return aDone ? 1 : -1;
    });

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-12 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-lg font-bold">আজকের সবক পর্যবেক্ষণ</h1>
        </div>
        <span className="text-xs text-amber-300 font-semibold px-2.5 py-1 rounded-full bg-emerald-950/60 border border-amber-400/30">
          দৈনিক হিসাব
        </span>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-3">
        {/* Top Summary Bar */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/80 mb-3 grid grid-cols-3 divide-x divide-slate-100 text-center">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">মোট ছাত্র</p>
            <p className="text-lg font-extrabold text-slate-800 mt-0.5">{total} জন</p>
          </div>
          <div>
            <p className="text-[11px] text-emerald-700 font-medium">সবক শেষ</p>
            <p className="text-lg font-extrabold text-emerald-600 mt-0.5">
              {completedCount} জন
            </p>
          </div>
          <div>
            <p className="text-[11px] text-red-600 font-medium">সবক বাকি</p>
            <p className="text-lg font-extrabold text-red-600 mt-0.5">
              {remainingCount} জন
            </p>
          </div>
        </div>

        {/* Search Bar & Filter Chips */}
        <div className="space-y-2.5 mb-4">
          <div className="bg-white rounded-xl shadow-xs border border-slate-200 px-3.5 py-2 flex items-center gap-2.5">
            <Search className="w-4 h-4 text-emerald-800 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="রোল বা নাম দিয়ে ছাত্র খুঁজুন..."
              className="w-full bg-transparent text-sm text-slate-800 placeholder-slate-400 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2">
            {(['সব', 'বাকি', 'শেষ'] as const).map((filter) => {
              const isSelected = filterStatus === filter;
              return (
                <button
                  key={filter}
                  onClick={() => setFilterStatus(filter)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-[#0A2E2B] text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {filter}
                </button>
              );
            })}
          </div>
        </div>

        {/* Student Cards List */}
        {filteredList.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো ছাত্রের তথ্য পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3.5">
            {filteredList.map((item) => (
              <DailySobokItemCard
                key={item.id}
                item={item}
                allThreeTypes={allThreeTypes}
                onStudentClick={() => onStudentClick(item.studentId)}
                onMarkSabakDone={(type, para, page) => {
                  const teacher = currentUser?.name || 'শিক্ষক';
                  onMarkCompleted(item.id, type, para, page, teacher);
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

interface DailySobokItemCardProps {
  item: DailySobokItem;
  allThreeTypes: string[];
  onStudentClick: () => void;
  onMarkSabakDone: (type: string, para: string, page: string) => void;
}

const DailySobokItemCard: React.FC<DailySobokItemCardProps> = ({
  item,
  allThreeTypes,
  onStudentClick,
  onMarkSabakDone
}) => {
  const [selectedType, setSelectedType] = useState<string>('সবক');
  const [paraInput, setParaInput] = useState<string>(item.mulSobokPara || '');
  const [pageInput, setPageInput] = useState<string>(item.mulSobokPage || '');

  const isAllThreeDone = allThreeTypes.every((t) => item.completedSabaks.includes(t));
  const isCurrentSelectedDone = item.completedSabaks.includes(selectedType);

  const handleTypeSelect = (type: string) => {
    setSelectedType(type);
    if (type === 'সবক') {
      setParaInput(item.mulSobokPara || '');
      setPageInput(item.mulSobokPage || '');
    } else if (type === 'সাত সবক') {
      setParaInput(item.satSobokPara || '');
      setPageInput(item.satSobokPage || '');
    } else if (type === 'আম্মোক্তা') {
      setParaInput(item.ammoktaPara || '');
      setPageInput(item.ammoktaPage || '');
    }
  };

  return (
    <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 hover:shadow-md transition-shadow">
      {/* Header: Roll, Student Name (clickable), Status Badge */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-100">
        <div
          onClick={onStudentClick}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-800 font-extrabold flex items-center justify-center text-sm group-hover:bg-emerald-100 group-hover:text-emerald-900 transition-colors">
            {item.studentRoll}
          </div>
          <div>
            <h3 className="font-bold text-base text-slate-900 group-hover:text-emerald-800 transition-colors flex items-center gap-1.5">
              {item.studentName}
            </h3>
            <p className="text-[11px] text-slate-500">
              নির্বাচিত: <span className="font-semibold text-emerald-800">{selectedType}</span>
            </p>
          </div>
        </div>

        {/* Status Badge: সবক শেষ only if all 3 completed, else সবক বাকি */}
        <div
          className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
            isAllThreeDone
              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-600 border border-red-200'
          }`}
        >
          {isAllThreeDone ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>সবক শেষ</span>
            </>
          ) : (
            <>
              <Clock className="w-3.5 h-3.5 text-red-500" />
              <span>সবক বাকি</span>
            </>
          )}
        </div>
      </div>

      {/* 3 Sabak Chips */}
      <div className="grid grid-cols-3 gap-2 mt-3">
        {allThreeTypes.map((type) => {
          const isDone = item.completedSabaks.includes(type);
          const isSelected = selectedType === type;

          return (
            <button
              key={type}
              type="button"
              onClick={() => handleTypeSelect(type)}
              className={`py-2 px-1 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                isSelected
                  ? 'bg-teal-700 text-white shadow-xs ring-2 ring-teal-600/30'
                  : isDone
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {isDone && <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />}
              <span className="truncate">{type}</span>
            </button>
          );
        })}
      </div>

      {/* Para & Page inputs for selected Sabak */}
      <div className="grid grid-cols-2 gap-2.5 mt-3">
        <div>
          <label className="block text-[11px] font-semibold text-slate-600 mb-1">
            পারা (পারা নং)
          </label>
          <input
            type="number"
            value={paraInput}
            onChange={(e) => setParaInput(e.target.value)}
            placeholder="পারা নং লিখুন"
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-emerald-700 focus:bg-white"
          />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-slate-600 mb-1">
            পৃষ্ঠা (পৃষ্ঠা নং)
          </label>
          <input
            type="number"
            value={pageInput}
            onChange={(e) => setPageInput(e.target.value)}
            placeholder="পৃষ্ঠা নং লিখুন"
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-emerald-700 focus:bg-white"
          />
        </div>
      </div>

      {/* Action Button: Mark single selected Sabak completed */}
      <button
        type="button"
        onClick={() => onMarkSabakDone(selectedType, paraInput, pageInput)}
        className={`w-full mt-3 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-xs active:scale-98 text-white ${
          isCurrentSelectedDone
            ? 'bg-emerald-700 hover:bg-emerald-800'
            : 'bg-[#2E7D32] hover:bg-emerald-700'
        }`}
      >
        <Check className="w-4 h-4" />
        <span>
          {isCurrentSelectedDone
            ? `${selectedType} আপডেট সম্পন্ন`
            : `${selectedType} সম্পন্ন করুন`}
        </span>
      </button>

      {/* Teacher Verification Log */}
      {item.completedByTeacher && (
        <div className="mt-2.5 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200/60 text-[11px] text-slate-600 flex items-center gap-1.5">
          <UserCheck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
          <span className="font-medium truncate">{item.completedByTeacher}</span>
        </div>
      )}
    </div>
  );
};
