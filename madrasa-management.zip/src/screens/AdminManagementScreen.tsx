import React, { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  Trash2,
  Shield,
  Phone,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { UserAccount } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';

interface AdminManagementScreenProps {
  users: UserAccount[];
  currentUser: UserAccount | null;
  onAddSecondAdmin: (name: string, phone: string, pass: string) => boolean;
  onDeleteSecondAdmin: (id: string) => void;
  onBack: () => void;
}

export const AdminManagementScreen: React.FC<AdminManagementScreenProps> = ({
  users,
  currentUser,
  onAddSecondAdmin,
  onDeleteSecondAdmin,
  onBack
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [adminToDelete, setAdminToDelete] = useState<UserAccount | null>(null);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const adminList = users.filter((u) => u.isMain || u.role === 'main' || u.role === 'sub');
  const isMainAdmin = currentUser?.isMain === true;

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!name.trim() || !phone.trim() || !password.trim()) {
      setErrorMsg('সকল তথ্য পূরণ করুন');
      return;
    }

    const success = onAddSecondAdmin(name.trim(), phone.trim(), password.trim());
    if (success) {
      setShowAddModal(false);
      setName('');
      setPhone('');
      setPassword('');
    } else {
      setErrorMsg('এই মোবাইল নম্বর দিয়ে আগেই এডমিন যোগ করা হয়েছে!');
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">এডমিন ব্যবস্থাপনা</h1>
            <p className="text-xs text-amber-300">প্রধান ও ২য় এডমিন এক্সেস</p>
          </div>
        </div>

        {isMainAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            ২য় এডমিন যোগ
          </button>
        )}
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4">
        {/* Permanent Main Admin Protection Banner */}
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 mb-4 flex items-start gap-3 text-amber-900 shadow-xs">
          <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed">
            <h4 className="font-bold text-amber-950">প্রধান এডমিন স্থায়ী সুরক্ষা</h4>
            <p className="mt-0.5">
              প্রধান পরিচালক <strong>MD Muhi Uddin</strong> স্থায়ী এডমিন। প্রধান এডমিনকে কোনোভাবেই পরিবর্তন বা মুছে ফেলা যাবে না। প্রধান এডমিন কেবল ২য় এডমিন যুক্ত বা বাদ দিতে পারবেন।
            </p>
          </div>
        </div>

        {/* Admins List */}
        <div className="space-y-3">
          {adminList.map((admin) => (
            <div
              key={admin.id}
              className={`bg-white rounded-2xl p-4 shadow-xs border flex items-center justify-between gap-3 ${
                admin.isMain ? 'border-amber-400/80 bg-amber-50/20' : 'border-slate-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-11 h-11 rounded-full flex items-center justify-center font-bold shrink-0 ${
                    admin.isMain
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900 leading-tight">
                    {admin.name}
                  </h3>
                  <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5 font-mono">
                    <Phone className="w-3 h-3" />
                    {admin.phone}
                  </p>
                  {admin.createdBy && (
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      তৈরি করেছে: {admin.createdBy}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                {admin.isMain ? (
                  <span className="bg-[#D4AF37] text-[#0A2E2B] text-xs font-extrabold px-3 py-1 rounded-full shadow-xs">
                    প্রধান এডমিন
                  </span>
                ) : (
                  <>
                    <span className="bg-slate-100 text-slate-700 text-xs font-bold px-2.5 py-1 rounded-full">
                      ২য় এডমিন
                    </span>
                    {isMainAdmin && (
                      <button
                        onClick={() => setAdminToDelete(admin)}
                        className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
                        title="২য় এডমিন মুছুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add 2nd Admin Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-amber-600" />
              নতুন ২য় এডমিন যুক্ত করুন
            </h3>

            {errorMsg && (
              <div className="bg-red-50 text-red-700 text-xs font-semibold p-2.5 rounded-xl mb-3 border border-red-200">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleAddSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ২য় এডমিনের নাম *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="যেমন: হাফেজ কারী আহমদ"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  মোবাইল নম্বর *
                </label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  লগইন পাসওয়ার্ড *
                </label>
                <input
                  type="text"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="পাসওয়ার্ড দিন"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  যোগ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete 2nd Admin Confirmation Modal (Point 1) */}
      <ConfirmModal
        isOpen={adminToDelete !== null}
        title="২য় এডমিন মুছে ফেলবেন?"
        message={`আপনি কি নিশ্চিত যে "${adminToDelete?.name}" (${adminToDelete?.phone})-কে ২য় এডমিন পদবী থেকে মুছে ফেলতে চান?`}
        confirmLabel="মুছে ফেলুন"
        cancelLabel="বাতিল"
        onConfirm={() => {
          if (adminToDelete) {
            onDeleteSecondAdmin(adminToDelete.id);
            setAdminToDelete(null);
          }
        }}
        onCancel={() => setAdminToDelete(null)}
      />
    </div>
  );
};
