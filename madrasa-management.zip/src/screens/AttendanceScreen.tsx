import React, { useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  Check,
  X,
  Clock,
  Users
} from 'lucide-react';
import { Student, AttendanceRecord } from '../types';

interface AttendanceScreenProps {
  students: Student[];
  attendanceList: AttendanceRecord[];
  onMarkAttendance: (
    student: Student,
    date: string,
    status: 'উপস্থিত' | 'অনুপস্থিত' | 'বিলম্ব'
  ) => void;
  onBack: () => void;
}

export const AttendanceScreen: React.FC<AttendanceScreenProps> = ({
  students,
  attendanceList,
  onMarkAttendance,
  onBack
}) => {
  const getToday = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
      d.getDate()
    ).padStart(2, '0')}`;
  };

  const [selectedDate, setSelectedDate] = useState(getToday());

  const todayRecords = attendanceList.filter((a) => a.date === selectedDate);
  const presentCount = todayRecords.filter((a) => a.status === 'উপস্থিত').length;
  const absentCount = todayRecords.filter((a) => a.status === 'অনুপস্থিত').length;
  const lateCount = todayRecords.filter((a) => a.status === 'বিলম্ব').length;

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">দৈনিক হাজিরা ব্যবস্থাপনা</h1>
            <p className="text-xs text-amber-300">উপস্থিতি ট্র্যাকিং</p>
          </div>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-3">
        {/* Date Selector & Stats */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 mb-4">
          <div className="flex items-center justify-between gap-3 mb-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-800" />
              <span className="text-xs font-bold text-slate-700">হাজিরার তারিখ:</span>
            </div>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-700"
            />
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5">
              <p className="text-[11px] font-semibold text-emerald-700">উপস্থিত</p>
              <p className="text-base font-extrabold text-emerald-900 mt-0.5">{presentCount}</p>
            </div>
            <div className="bg-red-50 border border-red-200 rounded-xl p-2.5">
              <p className="text-[11px] font-semibold text-red-700">অনুপস্থিত</p>
              <p className="text-base font-extrabold text-red-900 mt-0.5">{absentCount}</p>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-2.5">
              <p className="text-[11px] font-semibold text-amber-700">বিলম্ব</p>
              <p className="text-base font-extrabold text-amber-900 mt-0.5">{lateCount}</p>
            </div>
          </div>
        </div>

        {/* Student Attendance List */}
        {students.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো ছাত্রের তথ্য পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {students.map((student) => {
              const currentStatus = todayRecords.find((r) => r.studentId === student.id)?.status;

              return (
                <div
                  key={student.id}
                  className="bg-white rounded-2xl p-3.5 shadow-xs border border-slate-200/80 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 font-bold text-xs flex items-center justify-center text-slate-800">
                      {student.roll}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 leading-tight">
                        {student.name}
                      </h4>
                      <p className="text-[11px] text-slate-500">{student.className}</p>
                    </div>
                  </div>

                  {/* Attendance 3 buttons */}
                  <div className="flex items-center gap-1.5">
                    {/* Present */}
                    <button
                      onClick={() => onMarkAttendance(student, selectedDate, 'উপস্থিত')}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                        currentStatus === 'উপস্থিত'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      উপস্থিত
                    </button>

                    {/* Absent */}
                    <button
                      onClick={() => onMarkAttendance(student, selectedDate, 'অনুপস্থিত')}
                      className={`px-2 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                        currentStatus === 'অনুপস্থিত'
                          ? 'bg-red-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-red-50 hover:text-red-700'
                      }`}
                    >
                      <X className="w-3.5 h-3.5" />
                      অনুপস্থিত
                    </button>

                    {/* Late */}
                    <button
                      onClick={() => onMarkAttendance(student, selectedDate, 'বিলম্ব')}
                      className={`px-2 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                        currentStatus === 'বিলম্ব'
                          ? 'bg-amber-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-amber-50 hover:text-amber-700'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      বিলম্ব
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
