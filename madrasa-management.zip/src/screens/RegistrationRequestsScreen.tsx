import React, { useState } from 'react';
import {
  ArrowLeft,
  Check,
  X,
  UserPlus,
  Phone,
  Mail,
  Building,
  Calendar,
  Clock
} from 'lucide-react';
import { RegistrationRequest } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';

interface RegistrationRequestsScreenProps {
  requests: RegistrationRequest[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onBack: () => void;
}

export const RegistrationRequestsScreen: React.FC<RegistrationRequestsScreenProps> = ({
  requests,
  onApprove,
  onReject,
  onBack
}) => {
  const [filter, setFilter] = useState<'সব' | 'পেন্ডিং' | 'অনুমোদিত'>('সব');
  const [requestToReject, setRequestToReject] = useState<RegistrationRequest | null>(null);

  const filteredRequests = requests.filter((r) => {
    if (filter === 'পেন্ডিং') return r.status === 'pending';
    if (filter === 'অনুমোদিত') return r.status === 'approved';
    return true;
  });

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">রিকোয়েস্ট বক্স</h1>
            <p className="text-xs text-amber-300">রেজিস্ট্রেশন ও অনুমোদন বক্স</p>
          </div>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-3">
        {/* Filter Chips */}
        <div className="bg-white rounded-2xl p-2 shadow-xs border border-slate-200/80 mb-4 flex gap-2">
          {(['সব', 'পেন্ডিং', 'অনুমোদিত'] as const).map((tab) => {
            const isSelected = filter === tab;
            return (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  isSelected
                    ? 'bg-[#0A2E2B] text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {/* Requests List */}
        {filteredRequests.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <UserPlus className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো রেজিস্ট্রেশন আবেদন পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3.5">
            {filteredRequests.map((req) => (
              <div
                key={req.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                      <UserPlus className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-slate-900 leading-tight">
                        {req.name}
                      </h3>
                      <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        {req.role}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${
                      req.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : req.status === 'rejected'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {req.status === 'approved'
                      ? 'অনুমোদিত'
                      : req.status === 'rejected'
                      ? 'বাতিল'
                      : 'অপেক্ষমাণ (পেন্ডিং)'}
                  </span>
                </div>

                <div className="space-y-1 text-xs text-slate-600 my-2">
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-semibold text-slate-800 font-mono">মোবাইল: {req.mobile || req.phone}</span>
                  </p>
                  {req.email && (
                    <p className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-slate-400" />
                      <span>{req.email}</span>
                    </p>
                  )}
                  {req.feeDue ? (
                    <div className="bg-amber-50 px-2.5 py-1.5 rounded-lg border border-amber-200 text-amber-900 text-[11px] font-medium my-1">
                      রেজিস্ট্রেশন ফি: ৳{req.feeDue} • মাসিক ফি: ৳{req.monthlyFee || 200} ({req.feePaid ? 'পরিশোধিত' : 'বকেয়া'})
                    </div>
                  ) : null}
                  {req.madrasaName && (
                    <p className="flex items-center gap-1.5">
                      <Building className="w-3.5 h-3.5 text-slate-400" />
                      <span>মাদ্রাসা: {req.madrasaName}</span>
                    </p>
                  )}
                  {req.date && (
                    <p className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>আবেদনের তারিখ: {req.date}</span>
                    </p>
                  )}
                </div>

                {/* Action Buttons if pending */}
                {req.status === 'pending' && (
                  <div className="flex items-center gap-2 mt-3 pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => onApprove(req.id)}
                      className="flex-1 py-2 px-3 rounded-xl bg-[#2E7D32] hover:bg-emerald-800 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                    >
                      <Check className="w-4 h-4" />
                      অনুমোদন করুন
                    </button>
                    <button
                      type="button"
                      onClick={() => setRequestToReject(req)}
                      className="flex-1 py-2 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <X className="w-4 h-4" />
                      বাতিল করুন
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Reject Confirmation Modal (Point 1) */}
      <ConfirmModal
        isOpen={requestToReject !== null}
        title="আবেদন বাতিল করবেন?"
        message={`আপনি কি নিশ্চিত যে "${requestToReject?.name}"-এর রেজিস্ট্রেশন আবেদনটি বাতিল করতে চান?`}
        confirmLabel="বাতিল করুন"
        cancelLabel="ফিরে যান"
        onConfirm={() => {
          if (requestToReject) {
            onReject(requestToReject.id);
            setRequestToReject(null);
          }
        }}
        onCancel={() => setRequestToReject(null)}
      />
    </div>
  );
};
