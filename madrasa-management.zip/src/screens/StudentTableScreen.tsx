import React, { useState, useRef } from 'react';
import {
  ArrowLeft,
  Plus,
  Search,
  Trash2,
  Camera,
  GraduationCap
} from 'lucide-react';
import { Student } from '../types';
import { StudentAvatar } from '../components/StudentAvatar';
import { ConfirmModal } from '../components/ConfirmModal';

interface StudentTableScreenProps {
  students: Student[];
  isAdmin: boolean;
  onAddStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
  onStudentClick: (studentId: string) => void;
  onBack: () => void;
}

export const StudentTableScreen: React.FC<StudentTableScreenProps> = ({
  students,
  isAdmin,
  onAddStudent,
  onDeleteStudent,
  onStudentClick,
  onBack
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);

  // Add form fields
  const [newRoll, setNewRoll] = useState<string>(
    `${(students.length > 0 ? Math.max(...students.map((s) => s.roll)) : 0) + 1}`
  );
  const [newName, setNewName] = useState('');
  const [newClassName, setNewClassName] = useState('হিফজুল কুরআন');
  const [newSection, setNewSection] = useState('ক শাখা');
  const [newPhone, setNewPhone] = useState('');
  const [newFatherName, setNewFatherName] = useState('');
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredStudents = students
    .filter(
      (s) =>
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.roll.toString().includes(searchQuery) ||
        s.phone.includes(searchQuery) ||
        s.fatherName.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => a.roll - b.roll);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        // Compress/resize with canvas to keep Base64 compact
        const img = new Image();
        img.src = reader.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const maxDim = 300;
          let width = img.width;
          let height = img.height;
          if (width > height) {
            if (width > maxDim) {
              height *= maxDim / width;
              width = maxDim;
            }
          } else {
            if (height > maxDim) {
              width *= maxDim / height;
              height = maxDim;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.75);
          setNewPhotoUrl(compressedDataUrl);
        };
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const rollNum = parseInt(newRoll, 10) || students.length + 1;
    const newStudent: Student = {
      id: `st_${Date.now()}`,
      roll: rollNum,
      name: newName.trim(),
      className: newClassName,
      section: newSection,
      phone: newPhone.trim(),
      fatherName: newFatherName.trim(),
      photoUrl: newPhotoUrl,
      active: true
    };

    onAddStudent(newStudent);
    setShowAddModal(false);
    // Reset form
    setNewName('');
    setNewPhone('');
    setNewFatherName('');
    setNewPhotoUrl('');
    setNewRoll(`${rollNum + 1}`);
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">ছাত্র-ছাত্রীদের তালিকা</h1>
            <p className="text-xs text-amber-300">মোট: {students.length} জন</p>
          </div>
        </div>

        {isAdmin && (
          <button
            onClick={() => {
              setNewRoll(
                `${(students.length > 0 ? Math.max(...students.map((s) => s.roll)) : 0) + 1}`
              );
              setShowAddModal(true);
            }}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            নতুন ছাত্র
          </button>
        )}
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-3">
        {/* Search Bar */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 px-3.5 py-2 mb-4 flex items-center gap-2.5">
          <Search className="w-4 h-4 text-emerald-800 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="রোল, নাম, শ্রেণী বা মোবাইল নম্বর দিয়ে খুঁজুন..."
            className="w-full bg-transparent text-sm text-slate-800 placeholder-slate-400 focus:outline-none"
          />
        </div>

        {/* Responsive Table Card */}
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#0A2E2B] text-[#D4AF37] text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-3 text-center w-14">রোল</th>
                  <th className="py-3 px-3 text-center w-16">ছবি</th>
                  <th className="py-3 px-4">নাম</th>
                  <th className="py-3 px-4">শ্রেণী</th>
                  <th className="py-3 px-3">শাখা</th>
                  <th className="py-3 px-4">অভিভাবকের মোবাইল</th>
                  <th className="py-3 px-4">পিতার নাম</th>
                  {isAdmin && <th className="py-3 px-3 text-center w-16">অ্যাকশন</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td
                      colSpan={isAdmin ? 8 : 7}
                      className="py-12 text-center text-slate-400 font-medium"
                    >
                      কোনো ছাত্রের তথ্য পাওয়া যায়নি
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((s) => (
                    <tr
                      key={s.id}
                      className="hover:bg-emerald-50/50 transition-colors group"
                    >
                      {/* Roll */}
                      <td className="py-3 px-3 text-center font-extrabold text-slate-800">
                        {s.roll}
                      </td>

                      {/* Photo Avatar */}
                      <td className="py-2.5 px-3">
                        <div
                          onClick={() => onStudentClick(s.id)}
                          className="flex justify-center cursor-pointer"
                        >
                          <StudentAvatar photoUrl={s.photoUrl} name={s.name} size="sm" />
                        </div>
                      </td>

                      {/* Name (Clickable opens full 1-year history) */}
                      <td className="py-3 px-4 font-bold text-emerald-950">
                        <button
                          onClick={() => onStudentClick(s.id)}
                          className="text-left hover:text-emerald-700 hover:underline cursor-pointer flex items-center gap-1 group-hover:translate-x-0.5 transition-transform"
                        >
                          {s.name}
                        </button>
                      </td>

                      <td className="py-3 px-4 text-slate-700 font-medium">{s.className}</td>
                      <td className="py-3 px-3 text-slate-600">{s.section}</td>
                      <td className="py-3 px-4 text-slate-600 font-mono">{s.phone || '-'}</td>
                      <td className="py-3 px-4 text-slate-600">{s.fatherName || '-'}</td>

                      {/* Delete Action with Confirmation modal */}
                      {isAdmin && (
                        <td className="py-3 px-3 text-center">
                          <button
                            onClick={() => setStudentToDelete(s)}
                            className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-emerald-700" />
              নতুন ছাত্র যুক্ত করুন
            </h3>

            <form onSubmit={handleAddSubmit} className="space-y-3.5">
              {/* Photo Upload Preview */}
              <div className="flex flex-col items-center justify-center mb-2">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="w-20 h-20 rounded-full border-2 border-dashed border-emerald-700 bg-emerald-50 flex items-center justify-center overflow-hidden cursor-pointer relative group shadow-sm hover:border-emerald-900 transition-colors"
                >
                  {newPhotoUrl ? (
                    <img
                      src={newPhotoUrl}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Camera className="w-6 h-6 text-emerald-700 group-hover:scale-110 transition-transform" />
                  )}
                </div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handlePhotoUpload}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs font-bold text-emerald-800 mt-1.5 hover:underline"
                >
                  {newPhotoUrl ? 'ছবি পরিবর্তন করুন' : 'ছবি আপলোড করুন'}
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  রোল নম্বর *
                </label>
                <input
                  type="number"
                  required
                  value={newRoll}
                  onChange={(e) => setNewRoll(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ছাত্রের পুরো নাম *
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="যেমন: আব্দুর রহমান"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    শ্রেণী
                  </label>
                  <input
                    type="text"
                    value={newClassName}
                    onChange={(e) => setNewClassName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    শাখা
                  </label>
                  <input
                    type="text"
                    value={newSection}
                    onChange={(e) => setNewSection(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  অভিভাবকের মোবাইল নম্বর
                </label>
                <input
                  type="text"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  পিতার নাম
                </label>
                <input
                  type="text"
                  value={newFatherName}
                  onChange={(e) => setNewFatherName(e.target.value)}
                  placeholder="পিতার নাম লিখুন"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal (Point 1) */}
      <ConfirmModal
        isOpen={studentToDelete !== null}
        title="ছাত্রকে মুছে ফেলবেন?"
        message={`আপনি কি নিশ্চিত যে ছাত্র "${studentToDelete?.name}" (রোল: ${studentToDelete?.roll})-কে মুছে ফেলতে চান? এটি মুছে ফেললে তার সকল ডাটা ডিলিট হবে।`}
        confirmLabel="মুছে ফেলুন"
        cancelLabel="বাতিল"
        onConfirm={() => {
          if (studentToDelete) {
            onDeleteStudent(studentToDelete.id);
            setStudentToDelete(null);
          }
        }}
        onCancel={() => setStudentToDelete(null)}
      />
    </div>
  );
};
