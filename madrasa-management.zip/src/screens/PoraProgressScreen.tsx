import React, { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  BookOpen,
  Calendar,
  User,
  Target
} from 'lucide-react';
import { PoraProgressItem, Student, UserAccount } from '../types';

interface PoraProgressScreenProps {
  progressList: PoraProgressItem[];
  students: Student[];
  currentUser: UserAccount | null;
  onAddProgress: (item: PoraProgressItem) => void;
  onBack: () => void;
}

export const PoraProgressScreen: React.FC<PoraProgressScreenProps> = ({
  progressList,
  students,
  currentUser,
  onAddProgress,
  onBack
}) => {
  const [showAddModal, setShowAddModal] = useState(false);

  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    students[0]?.id || ''
  );
  const [mainSobok, setMainSobok] = useState('');
  const [satSobok, setSatSobok] = useState('');
  const [ammokta, setAmmokta] = useState('');
  const [dailyTarget, setDailyTarget] = useState('প্রতিদিন ১ পৃষ্ঠা সবক ও ৫ পৃষ্ঠা আম্মোক্তা');
  const [progressNote, setProgressNote] = useState('পড়া মাশাআল্লাহ ভালো হয়েছে।');

  const canAdd =
    currentUser?.role === 'main' ||
    currentUser?.role === 'sub' ||
    currentUser?.role === 'teacher';

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const st = students.find((s) => s.id === selectedStudentId);
    if (!st) return;

    onAddProgress({
      id: `pp_${Date.now()}`,
      studentId: st.id,
      studentName: st.name,
      studentRoll: st.roll,
      mainSobok: mainSobok.trim(),
      satSobok: satSobok.trim(),
      ammokta: ammokta.trim(),
      dailyTarget: dailyTarget.trim(),
      progressNote: progressNote.trim(),
      recordedBy: currentUser?.name || 'শিক্ষক',
      date: new Date().toLocaleDateString('bn-BD')
    });

    setShowAddModal(false);
    setMainSobok('');
    setSatSobok('');
    setAmmokta('');
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">পড়া অগ্রগতি ব্যবস্থাপনা</h1>
            <p className="text-xs text-amber-300">দৈনিক পড়া ট্র্যাকিং</p>
          </div>
        </div>

        {canAdd && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            অগ্রগতি যোগ
          </button>
        )}
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4">
        {/* Banner */}
        <div className="bg-emerald-900/10 border border-emerald-900/20 rounded-2xl p-3.5 mb-4 flex items-center gap-3 text-emerald-950">
          <BookOpen className="w-5 h-5 text-emerald-800 shrink-0" />
          <p className="text-xs font-semibold leading-relaxed">
            হিফজ ও নাজেরা বিভাগের ছাত্রছাত্রীদের দৈনন্দিন মুল সবক, সাত সবক ও আম্মোক্তার লক্ষ্যমাত্রা ও রেকর্ড।
          </p>
        </div>

        {progressList.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <Target className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো পড়া অগ্রগতির রেকর্ড পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3.5">
            {progressList.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-900 font-bold text-xs flex items-center justify-center">
                      {item.studentRoll}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{item.studentName}</h4>
                      <p className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {item.date}
                      </p>
                    </div>
                  </div>
                  {item.recordedBy && (
                    <span className="text-[11px] text-emerald-800 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      শিক্ষক: {item.recordedBy}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-2 my-3 text-center">
                  <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    <p className="text-[10px] text-slate-500 font-medium">মুল সবক</p>
                    <p className="text-xs font-bold text-emerald-900 mt-0.5">
                      {item.mainSobok || '-'}
                    </p>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    <p className="text-[10px] text-slate-500 font-medium">সাত সবক</p>
                    <p className="text-xs font-bold text-amber-900 mt-0.5">
                      {item.satSobok || '-'}
                    </p>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    <p className="text-[10px] text-slate-500 font-medium">আম্মোক্তা</p>
                    <p className="text-xs font-bold text-purple-900 mt-0.5">
                      {item.ammokta || '-'}
                    </p>
                  </div>
                </div>

                {item.dailyTarget && (
                  <p className="text-xs text-slate-700 mt-1">
                    <span className="font-bold text-emerald-950">লক্ষ্যমাত্রা: </span>
                    {item.dailyTarget}
                  </p>
                )}

                {item.progressNote && (
                  <p className="text-xs text-slate-500 mt-1 italic">
                    মন্তব্য: {item.progressNote}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Progress Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-700" />
              পড়া অগ্রগতি যোগ করুন
            </h3>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ছাত্র নির্বাচন *</label>
                <select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      রোল {s.roll}: {s.name} ({s.className})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">মুল সবক</label>
                <input
                  type="text"
                  value={mainSobok}
                  onChange={(e) => setMainSobok(e.target.value)}
                  placeholder="যেমন: পারা ১৫, পৃষ্ঠা ১২"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">সাত সবক</label>
                <input
                  type="text"
                  value={satSobok}
                  onChange={(e) => setSatSobok(e.target.value)}
                  placeholder="যেমন: পারা ১৫, পৃষ্ঠা ৫-১১"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">আম্মোক্তা</label>
                <input
                  type="text"
                  value={ammokta}
                  onChange={(e) => setAmmokta(e.target.value)}
                  placeholder="যেমন: পারা ১-১৪"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">দৈনিক লক্ষ্যমাত্রা</label>
                <input
                  type="text"
                  value={dailyTarget}
                  onChange={(e) => setDailyTarget(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">অগ্রগতি সংক্রান্ত মন্তব্য</label>
                <input
                  type="text"
                  value={progressNote}
                  onChange={(e) => setProgressNote(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
