import React, { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  Trash2,
  Bell,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { NoticeItem } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';

interface NoticeScreenProps {
  notices: NoticeItem[];
  isAdmin: boolean;
  onAddNotice: (notice: NoticeItem) => void;
  onDeleteNotice: (id: string) => void;
  onBack: () => void;
}

export const NoticeScreen: React.FC<NoticeScreenProps> = ({
  notices,
  isAdmin,
  onAddNotice,
  onDeleteNotice,
  onBack
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [noticeToDelete, setNoticeToDelete] = useState<NoticeItem | null>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isImportant, setIsImportant] = useState(false);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    onAddNotice({
      id: `nt_${Date.now()}`,
      title: title.trim(),
      description: description.trim(),
      date: new Date().toLocaleDateString('bn-BD'),
      isImportant
    });

    setShowAddModal(false);
    setTitle('');
    setDescription('');
    setIsImportant(false);
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">নোটিশ বোর্ড</h1>
            <p className="text-xs text-amber-300">মাদ্রাসার বিজ্ঞপ্তি ও ঘোষণা</p>
          </div>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            নতুন নোটিশ
          </button>
        )}
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4">
        {notices.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <Bell className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো নোটিশ পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3.5">
            {notices.map((n) => (
              <div
                key={n.id}
                className={`bg-white rounded-2xl p-4 shadow-xs border transition-shadow ${
                  n.isImportant ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200/90'
                }`}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-start gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        n.isImportant
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {n.isImportant ? (
                        <AlertCircle className="w-5 h-5" />
                      ) : (
                        <Bell className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-slate-900 leading-snug">
                        {n.title}
                      </h3>
                      <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                        <Calendar className="w-3 h-3" />
                        {n.date}
                      </p>
                    </div>
                  </div>

                  {isAdmin && (
                    <button
                      onClick={() => setNoticeToDelete(n)}
                      className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors shrink-0"
                      title="নোটিশ মুছুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <p className="text-sm text-slate-600 leading-relaxed pl-11 whitespace-pre-wrap">
                  {n.description}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Notice Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <Bell className="w-5 h-5 text-emerald-700" />
              নতুন নোটিশ প্রকাশ করুন
            </h3>

            <form onSubmit={handleAddSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  নোটিশের শিরোনাম *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="যেমন: মাসিক পরীক্ষা ও ছুটি সংক্রান্ত নোটিশ"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  বিস্তারিত বিবরণ *
                </label>
                <textarea
                  required
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="নোটিশের বিস্তারিত বিবরণ লিখুন..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="importantCheck"
                  checked={isImportant}
                  onChange={(e) => setIsImportant(e.target.checked)}
                  className="w-4 h-4 accent-emerald-700 rounded"
                />
                <label htmlFor="importantCheck" className="text-xs font-semibold text-slate-700 cursor-pointer">
                  জরুরী নোটিশ হিসেবে চিহ্নিত করুন
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  প্রকাশ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal (Point 1) */}
      <ConfirmModal
        isOpen={noticeToDelete !== null}
        title="নোটিশ মুছে ফেলবেন?"
        message={`আপনি কি নিশ্চিত যে "${noticeToDelete?.title}" নোটিশটি মুছে ফেলতে চান?`}
        confirmLabel="মুছে ফেলুন"
        cancelLabel="বাতিল"
        onConfirm={() => {
          if (noticeToDelete) {
            onDeleteNotice(noticeToDelete.id);
            setNoticeToDelete(null);
          }
        }}
        onCancel={() => setNoticeToDelete(null)}
      />
    </div>
  );
};
