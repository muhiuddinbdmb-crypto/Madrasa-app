import React, { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  Receipt,
  CheckCircle2,
  Clock,
  Printer
} from 'lucide-react';
import { FeeRecord, Student } from '../types';

interface FeeScreenProps {
  feeList: FeeRecord[];
  students: Student[];
  isAdmin: boolean;
  onAddFeeRecord: (fee: FeeRecord) => void;
  onMarkFeePaid: (id: string, amount: number) => void;
  onBack: () => void;
}

export const FeeScreen: React.FC<FeeScreenProps> = ({
  feeList,
  students,
  isAdmin,
  onAddFeeRecord,
  onMarkFeePaid,
  onBack
}) => {
  const [filter, setFilter] = useState<'সব' | 'বকেয়া' | 'পরিশোধিত'>('সব');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<FeeRecord | null>(null);

  // Add form fields
  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    students[0]?.id || ''
  );
  const [monthYear, setMonthYear] = useState('অক্টোবর ২০২৬');
  const [amount, setAmount] = useState('১৫০০');

  const totalCollected = feeList
    .filter((f) => f.isPaid)
    .reduce((sum, f) => sum + f.paidAmount, 0);

  const totalDue = feeList
    .filter((f) => !f.isPaid)
    .reduce((sum, f) => sum + f.amount, 0);

  const filteredFees = feeList.filter((f) => {
    if (filter === 'বকেয়া') return !f.isPaid;
    if (filter === 'পরিশোধিত') return f.isPaid;
    return true;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const st = students.find((s) => s.id === selectedStudentId);
    if (!st) return;

    onAddFeeRecord({
      id: `fee_${Date.now()}`,
      studentId: st.id,
      studentName: st.name,
      studentRoll: st.roll,
      monthYear,
      amount: parseInt(amount, 10) || 1000,
      paidAmount: 0,
      isPaid: false,
      paymentDate: '',
      receiptNumber: ''
    });

    setShowAddModal(false);
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold">ফি কালেকশন ব্যবস্থাপনা</h1>
            <p className="text-xs text-amber-300">মাসিক ফি ও রসিদ</p>
          </div>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 rounded-full bg-[#D4AF37] text-[#0A2E2B] font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-amber-400 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            নতুন ফি নির্ধারণ
          </button>
        )}
      </div>

      <div className="max-w-xl mx-auto px-4 pt-3">
        {/* Top Summary Cards */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/70 p-4 rounded-2xl border border-emerald-200 shadow-xs">
            <p className="text-xs font-semibold text-emerald-800">মোট আদায়কৃত ফি</p>
            <p className="text-xl font-extrabold text-emerald-900 mt-1">
              ৳ {totalCollected.toLocaleString('bn-BD')}
            </p>
          </div>

          <div className="bg-gradient-to-br from-red-50 to-red-100/70 p-4 rounded-2xl border border-red-200 shadow-xs">
            <p className="text-xs font-semibold text-red-800">মোট বকেয়া ফি</p>
            <p className="text-xl font-extrabold text-red-900 mt-1">
              ৳ {totalDue.toLocaleString('bn-BD')}
            </p>
          </div>
        </div>

        {/* Filter Chips */}
        <div className="flex gap-2 mb-4">
          {(['সব', 'বকেয়া', 'পরিশোধিত'] as const).map((tab) => {
            const isSelected = filter === tab;
            return (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  isSelected
                    ? 'bg-[#0A2E2B] text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {/* Fees List */}
        {filteredFees.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <Receipt className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো ফি রেকর্ড পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredFees.map((fee) => (
              <div
                key={fee.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 flex items-center justify-between gap-3 hover:shadow-md transition-shadow"
              >
                <div>
                  <h4 className="font-bold text-sm text-slate-900 leading-tight">
                    {fee.studentName} <span className="text-xs text-slate-500">(রোল: {fee.studentRoll})</span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">মাস: {fee.monthYear}</p>
                  <p className="text-sm font-extrabold text-emerald-950 mt-1">
                    ৳ {fee.amount}
                  </p>
                </div>

                <div className="text-right">
                  <span
                    className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full mb-2 ${
                      fee.isPaid
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-red-50 text-red-600 border border-red-200'
                    }`}
                  >
                    {fee.isPaid ? (
                      <>
                        <CheckCircle2 className="w-3 h-3" />
                        পরিশোধিত
                      </>
                    ) : (
                      <>
                        <Clock className="w-3 h-3" />
                        বকেয়া
                      </>
                    )}
                  </span>

                  <div>
                    {!fee.isPaid && isAdmin ? (
                      <button
                        onClick={() => onMarkFeePaid(fee.id, fee.amount)}
                        className="px-3 py-1.5 rounded-xl bg-[#2E7D32] hover:bg-emerald-800 text-white text-xs font-bold transition-colors shadow-xs active:scale-95"
                      >
                        পরিশোধ করুন
                      </button>
                    ) : (
                      <button
                        onClick={() => setSelectedReceipt(fee)}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        রসিদ দেখুন
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Fee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <h3 className="text-lg font-bold text-[#0A2E2B] mb-4 flex items-center gap-2">
              <Receipt className="w-5 h-5 text-emerald-700" />
              নতুন ফি নির্ধারণ
            </h3>

            <form onSubmit={handleAddSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ছাত্র নির্বাচন *</label>
                <select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      রোল {s.roll}: {s.name} ({s.className})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">মাস ও বছর *</label>
                <input
                  type="text"
                  required
                  value={monthYear}
                  onChange={(e) => setMonthYear(e.target.value)}
                  placeholder="যেমন: অক্টোবর ২০২৬"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">টাকার পরিমাণ (৳) *</label>
                <input
                  type="number"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printable Receipt Modal */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-200 text-slate-800">
            {/* Madrasa Letterhead Header */}
            <div className="text-center pb-4 border-b border-dashed border-slate-300">
              <h3 className="font-bold text-sm text-[#0A2E2B] leading-tight">
                হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা
              </h3>
              <p className="text-[10px] text-slate-500 mt-0.5">প্রতিষ্ঠিত: ২০১৩ খ্রিষ্টাব্দ</p>
              <div className="inline-block mt-2 px-3 py-0.5 bg-emerald-100 text-emerald-900 rounded-full font-bold text-xs">
                ফি আদায়ের রসিদ
              </div>
            </div>

            {/* Receipt Details */}
            <div className="py-4 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>রসিদ নং:</span>
                <span className="font-mono font-bold text-slate-900">
                  {selectedReceipt.receiptNumber || 'REC-1082'}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>তারিখ:</span>
                <span className="font-semibold text-slate-900">
                  {selectedReceipt.paymentDate || new Date().toLocaleDateString('bn-BD')}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>ছাত্রের নাম:</span>
                <span className="font-bold text-slate-900">{selectedReceipt.studentName}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>রোল নম্বর:</span>
                <span className="font-bold text-slate-900">{selectedReceipt.studentRoll}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>মাসের বিবরণ:</span>
                <span className="font-semibold text-slate-900">{selectedReceipt.monthYear}</span>
              </div>

              <div className="border-t border-slate-200 pt-2 flex justify-between text-sm font-extrabold text-emerald-950">
                <span>আদায়কৃত টাকা:</span>
                <span>৳ {selectedReceipt.paidAmount || selectedReceipt.amount}</span>
              </div>
            </div>

            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-center text-[10px] text-slate-500 mb-4">
              যাচাইকারী: প্রধান পরিচালক (MD Muhi Uddin)
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSelectedReceipt(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
              >
                বন্ধ করুন
              </button>
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="flex-1 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Printer className="w-3.5 h-3.5" />
                প্রিন্ট করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
