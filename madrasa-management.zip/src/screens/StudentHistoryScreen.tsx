import React, { useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  Filter,
  Trash2,
  Phone,
  BookOpen,
  CheckCircle2
} from 'lucide-react';
import { Student, SabakHistoryRecord } from '../types';
import { StudentAvatar } from '../components/StudentAvatar';
import { ConfirmModal } from '../components/ConfirmModal';

interface StudentHistoryScreenProps {
  student?: Student;
  historyList: SabakHistoryRecord[];
  isAdmin: boolean;
  onDeleteHistoryItem: (historyId: string) => void;
  onBack: () => void;
}

export const StudentHistoryScreen: React.FC<StudentHistoryScreenProps> = ({
  student,
  historyList,
  isAdmin,
  onDeleteHistoryItem,
  onBack
}) => {
  const [selectedMonthFilter, setSelectedMonthFilter] = useState('সব');
  const [itemToDelete, setItemToDelete] = useState<SabakHistoryRecord | null>(null);

  if (!student) {
    return (
      <div className="min-h-screen bg-[#F4F7F5] flex flex-col items-center justify-center p-6 text-center">
        <p className="text-slate-600 font-medium mb-4">ছাত্রের তথ্য পাওয়া যায়নি</p>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-emerald-800 text-white rounded-xl text-sm font-bold"
        >
          ফিরে যান
        </button>
      </div>
    );
  }

  // Extract available months dynamically
  const availableMonths = [
    'সব',
    ...Array.from(new Set(historyList.map((h) => h.date.slice(0, 7)).filter(Boolean)))
  ];

  const filteredHistory = historyList.filter((item) => {
    if (selectedMonthFilter === 'সব') return true;
    return item.date.startsWith(selectedMonthFilter);
  });

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-12 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold leading-tight">{student.name}</h1>
            <p className="text-xs text-amber-300">১ বছরের সম্পূর্ণ সবক ইতিহাস</p>
          </div>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-3">
        {/* Student Profile Card */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/90 mb-4 flex items-center gap-4">
          <StudentAvatar photoUrl={student.photoUrl} name={student.name} size="lg" />

          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-bold text-slate-900 truncate">{student.name}</h2>
            <p className="text-xs text-emerald-800 font-semibold">
              রোল: {student.roll} | শ্রেণী: {student.className} ({student.section})
            </p>
            {student.phone && (
              <p className="text-xs text-slate-600 flex items-center gap-1 mt-0.5">
                <Phone className="w-3 h-3 text-slate-400" />
                অভিভাবক: {student.phone}
              </p>
            )}
            {student.fatherName && (
              <p className="text-xs text-slate-500">পিতার নাম: {student.fatherName}</p>
            )}
          </div>
        </div>

        {/* Month Filter Bar */}
        <div className="bg-white rounded-xl p-3 shadow-xs border border-slate-200 mb-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <Filter className="w-4 h-4 text-emerald-800" />
            <span>মাস অনুযায়ী ফিল্টার:</span>
          </div>

          <select
            value={selectedMonthFilter}
            onChange={(e) => setSelectedMonthFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-semibold text-emerald-900 focus:outline-none focus:ring-1 focus:ring-emerald-700"
          >
            {availableMonths.map((m) => (
              <option key={m} value={m}>
                {m === 'সব' ? 'সব রেকর্ড' : m}
              </option>
            ))}
          </select>
        </div>

        {/* Sabak History List */}
        {filteredHistory.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-xs border border-slate-200 text-slate-500">
            <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">কোনো সবক হিস্টোরি রেকর্ড পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredHistory.map((record) => (
              <div
                key={record.id}
                className="bg-white rounded-2xl p-3.5 shadow-xs border border-slate-200 flex items-center justify-between gap-3 hover:shadow-sm transition-shadow"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-xs font-bold px-2.5 py-0.5 rounded-md ${
                        record.sabakType === 'সবক'
                          ? 'bg-teal-50 text-teal-800 border border-teal-200'
                          : record.sabakType === 'সাত সবক'
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-purple-50 text-purple-800 border border-purple-200'
                      }`}
                    >
                      {record.sabakType}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1 font-medium">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      {record.date}
                    </span>
                  </div>

                  {/* Para & Page info */}
                  <p className="text-sm font-bold text-emerald-950">
                    {record.para ? `পারা: ${record.para}` : ''}
                    {record.para && record.page ? ', ' : ''}
                    {record.page ? `পৃষ্ঠা: ${record.page}` : ''}
                  </p>

                  {/* Teacher & Time */}
                  <p className="text-xs text-slate-600 mt-0.5">
                    যাচাইকারী: <span className="font-semibold">{record.teacherName}</span>
                    {record.time && ` (${record.time})`}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    {record.status}
                  </span>

                  {/* Admin Delete Trash Button with Confirmation Dialog */}
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={() => setItemToDelete(record)}
                      className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
                      title="রেকর্ড মুছুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Confirmation Dialog for Record Deletion */}
      <ConfirmModal
        isOpen={itemToDelete !== null}
        title="রেকর্ড মুছে ফেলবেন?"
        message={`আপনি কি নিশ্চিত যে ${itemToDelete?.date} তারিখের ${itemToDelete?.sabakType} রেকর্ডটি মুছে ফেলতে চান?`}
        confirmLabel="মুছে ফেলুন"
        cancelLabel="বাতিল"
        onConfirm={() => {
          if (itemToDelete) {
            onDeleteHistoryItem(itemToDelete.id);
            setItemToDelete(null);
          }
        }}
        onCancel={() => setItemToDelete(null)}
      />
    </div>
  );
};
