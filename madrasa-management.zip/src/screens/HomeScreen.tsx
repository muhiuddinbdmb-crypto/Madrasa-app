import React, { useState } from 'react';
import {
  Users,
  GraduationCap,
  Calendar,
  CheckSquare,
  Award,
  UserPlus,
  BookOpen,
  CreditCard,
  Bell,
  Search,
  ChevronRight,
  BookMarked
} from 'lucide-react';
import { MadrasaHeader } from '../components/MadrasaHeader';
import { FloatingBottomNavBar } from '../components/FloatingBottomNavBar';
import { ScreenType, Student, Teacher, NoticeItem } from '../types';

interface HomeScreenProps {
  students: Student[];
  teachers: Teacher[];
  remainingSobokCount: number;
  totalStudents: number;
  pendingRequestsCount: number;
  latestNotice?: NoticeItem;
  syncStatusText: string;
  isSyncing: boolean;
  onNavigate: (screen: ScreenType) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  students,
  teachers,
  remainingSobokCount,
  totalStudents,
  pendingRequestsCount,
  latestNotice,
  syncStatusText,
  isSyncing,
  onNavigate
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-24 text-slate-800">
      {/* 1. Header: 100% visible with logo, madrasa name, principal info, and sync badge */}
      <MadrasaHeader
        syncStatusText={syncStatusText}
        isSyncing={isSyncing}
      />

      <div className="max-w-xl mx-auto px-4">
        {/* 2. Search Bar completely BELOW header in normal Column flow with 16dp margin */}
        <div className="my-4">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 px-4 py-2.5 flex items-center gap-3">
            <Search className="w-5 h-5 text-emerald-800 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ছাত্র বা শিক্ষকের নাম দিয়ে খুঁজুন..."
              className="w-full bg-transparent text-sm text-slate-800 placeholder-slate-400 focus:outline-none"
            />
          </div>
        </div>

        {/* 3. Section 1: Dashboard Summary Cards */}
        <div className="mb-5">
          <h2 className="text-sm font-bold text-[#0A2E2B] mb-2.5 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
            মাদ্রাসার সংক্ষিপ্ত তথ্য
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {/* Total Students Card */}
            <button
              onClick={() => onNavigate('studentTable')}
              className="bg-gradient-to-br from-blue-50 to-blue-100/70 p-3.5 rounded-2xl border border-blue-200/60 shadow-xs flex items-center gap-3 text-left hover:shadow-md transition-all active:scale-98"
            >
              <div className="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-slate-600 font-medium">মোট ছাত্র</p>
                <p className="text-lg font-extrabold text-slate-900 mt-0.5">
                  {students.length} জন
                </p>
              </div>
            </button>

            {/* Total Teachers Card */}
            <button
              onClick={() => onNavigate('teacherList')}
              className="bg-gradient-to-br from-orange-50 to-orange-100/70 p-3.5 rounded-2xl border border-orange-200/60 shadow-xs flex items-center gap-3 text-left hover:shadow-md transition-all active:scale-98"
            >
              <div className="w-11 h-11 rounded-full bg-orange-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-slate-600 font-medium">মোট শিক্ষক</p>
                <p className="text-lg font-extrabold text-slate-900 mt-0.5">
                  {teachers.length} জন
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* 4. Section 2: Main Menu & Activities Grid */}
        <div className="mb-5">
          <h2 className="text-sm font-bold text-[#0A2E2B] mb-2.5 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
            প্রধান কার্যক্রমসমূহ
          </h2>

          <div className="grid grid-cols-2 gap-3">
            {/* Teachers Card */}
            <button
              onClick={() => onNavigate('teacherList')}
              className="bg-gradient-to-br from-amber-50 to-amber-100/60 p-3.5 rounded-2xl border border-amber-200/60 shadow-xs flex items-center gap-3 text-left hover:shadow-md transition-all active:scale-98"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900">শিক্ষকগণ</p>
                <p className="text-[11px] text-slate-500 leading-tight">তালিকা ও প্রোফাইল</p>
              </div>
            </button>

            {/* Ajker Sobok Card (Showing remaining pending count) */}
            <button
              onClick={() => onNavigate('dailySobok')}
              className="bg-gradient-to-br from-teal-50 to-teal-100/70 p-3.5 rounded-2xl border border-teal-200/60 shadow-xs flex items-center gap-3 text-left hover:shadow-md transition-all active:scale-98 relative overflow-hidden"
            >
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <BookMarked className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-teal-900">আজকের সবক</p>
                <p className="text-lg font-extrabold text-teal-700 leading-tight">
                  {remainingSobokCount} <span className="text-[11px] font-medium text-teal-800">বাকি</span>
                </p>
                <p className="text-[10px] text-teal-700/80">মোট: {totalStudents}</p>
              </div>
            </button>

            {/* Attendance Card */}
            <button
              onClick={() => onNavigate('attendance')}
              className="bg-gradient-to-br from-emerald-50 to-emerald-100/60 p-3.5 rounded-2xl border border-emerald-200/60 shadow-xs flex items-center gap-3 text-left hover:shadow-md transition-all active:scale-98"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <CheckSquare className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900">উপস্থিতি</p>
                <p className="text-[11px] text-slate-500 leading-tight">দৈনিক হাজিরা</p>
              </div>
            </button>

            {/* Routine Card */}
            <button
              onClick={() => onNavigate('routine')}
              className="bg-gradient-to-br from-rose-50 to-rose-100/60 p-3.5 rounded-2xl border border-rose-200/60 shadow-xs flex items-center gap-3 text-left hover:shadow-md transition-all active:scale-98"
            >
              <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900">রুটিন</p>
                <p className="text-[11px] text-slate-500 leading-tight">ক্লাস ও কাজের সূচি</p>
              </div>
            </button>

            {/* Exam Results Card */}
            <button
              onClick={() => onNavigate('exam')}
              className="bg-gradient-to-br from-purple-50 to-purple-100/60 p-3.5 rounded-2xl border border-purple-200/60 shadow-xs flex items-center gap-3 text-left hover:shadow-md transition-all active:scale-98"
            >
              <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900">পরীক্ষার ফলাফল</p>
                <p className="text-[11px] text-slate-500 leading-tight">গ্রেড ও মূল্যায়ন</p>
              </div>
            </button>

            {/* Request Box (Item 8: Settings box replaced with Request box with pending badge) */}
            <button
              onClick={() => onNavigate('registrationRequests')}
              className="bg-gradient-to-br from-amber-50 via-amber-100/70 to-yellow-100 p-3.5 rounded-2xl border border-amber-300/80 shadow-xs flex items-center gap-3 text-left hover:shadow-md transition-all active:scale-98 relative"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <UserPlus className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-bold text-slate-900">রিকোয়েস্ট বক্স</p>
                  {pendingRequestsCount > 0 && (
                    <span className="bg-red-600 text-white text-[10px] font-extrabold px-1.5 py-0.2 rounded-full animate-pulse">
                      {pendingRequestsCount}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-amber-900/80 font-medium leading-tight">
                  {pendingRequestsCount > 0 ? `${pendingRequestsCount} টি আবেদন পেন্ডিং` : 'সকল আবেদন'}
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* 5. Section 3: Extra Features (Pora Progress & Fee Collection) */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <button
            onClick={() => onNavigate('poraProgress')}
            className="bg-[#0A2E2B] text-white p-3.5 rounded-2xl shadow-sm flex items-center gap-3 text-left hover:bg-[#0D3B37] transition-all active:scale-98"
          >
            <div className="w-9 h-9 rounded-full bg-amber-400/20 text-amber-300 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold">পড়া অগ্রগতি</p>
              <p className="text-[11px] text-amber-200/80">দৈনিক ট্র্যাকিং</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('fee')}
            className="bg-slate-800 text-white p-3.5 rounded-2xl shadow-sm flex items-center gap-3 text-left hover:bg-slate-700 transition-all active:scale-98"
          >
            <div className="w-9 h-9 rounded-full bg-sky-400/20 text-sky-300 flex items-center justify-center shrink-0">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold">ফি কালেকশন</p>
              <p className="text-[11px] text-slate-300">আদায় ও রসিদ</p>
            </div>
          </button>
        </div>

        {/* 6. Section 4: Notice Board Preview */}
        <div className="mb-6">
          <div
            onClick={() => onNavigate('notice')}
            className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200/80 hover:shadow-md transition-all cursor-pointer"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center">
                  <Bell className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-sm text-[#0A2E2B]">নোটিশ বোর্ড</h3>
              </div>
              <span className="text-xs font-semibold text-emerald-700 flex items-center gap-0.5">
                সব দেখুন <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </div>

            {latestNotice ? (
              <div className="mt-1">
                <p className="text-sm font-semibold text-slate-900 line-clamp-1">
                  {latestNotice.title}
                </p>
                <p className="text-xs text-slate-500 line-clamp-2 mt-0.5">
                  {latestNotice.description}
                </p>
                <p className="text-[10px] text-slate-400 mt-1">তারিখ: {latestNotice.date}</p>
              </div>
            ) : (
              <p className="text-xs text-slate-400 mt-1">কোনো নতুন নোটিশ নেই</p>
            )}
          </div>
        </div>
      </div>

      {/* Floating Bottom Nav Bar */}
      <FloatingBottomNavBar currentScreen="home" onNavigate={onNavigate} />
    </div>
  );
};
