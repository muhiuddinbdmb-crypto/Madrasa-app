import React, { useState } from 'react';
import {
  ArrowLeft,
  Building,
  CheckCircle2,
  Phone,
  CreditCard,
  ShieldCheck
} from 'lucide-react';
import { MadrasaRegistration } from '../types';

interface OtherMadrasaRegScreenProps {
  onBack: () => void;
  onSubmit: (reg: MadrasaRegistration) => void;
}

export const OtherMadrasaRegScreen: React.FC<OtherMadrasaRegScreenProps> = ({
  onBack,
  onSubmit
}) => {
  const [madrasaName, setMadrasaName] = useState('');
  const [address, setAddress] = useState('');
  const [adminName, setAdminName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!madrasaName.trim() || !phone.trim() || !password.trim()) return;

    onSubmit({
      id: `reg_${Date.now()}`,
      madrasaName: madrasaName.trim(),
      address: address.trim(),
      adminName: adminName.trim(),
      phone: phone.trim(),
      email: email.trim(),
      password: password.trim(),
      status: 'PENDING',
      registeredDate: new Date().toLocaleDateString('bn-BD'),
      paymentNote: 'বিকাশ নম্বর: 01715047342'
    });

    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-[#F4F7F5] pb-16 text-slate-800">
      {/* Top Header */}
      <div className="bg-[#0A2E2B] text-white p-4 shadow-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-base font-bold">অন্যান্য মাদ্রাসা রেজিস্ট্রেশন</h1>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4">
        {submitted ? (
          <div className="bg-white rounded-3xl p-8 shadow-md border border-slate-200 text-center space-y-4 my-6">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <h2 className="text-xl font-bold text-slate-900">
              রেজিস্ট্রেশন আবেদন সফল হয়েছে!
            </h2>

            <p className="text-sm text-slate-600 leading-relaxed max-w-sm mx-auto">
              আপনার মাদ্রাসার তথ্য সফলভাবে জমা নেওয়া হয়েছে। প্রধান পরিচালকের অনুমোদন পাওয়ার পর আপনি লগইন করতে পারবেন।
            </p>

            <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 text-left text-xs text-amber-950 space-y-1">
              <p className="font-bold text-sm text-amber-900 flex items-center gap-1.5">
                <CreditCard className="w-4 h-4" />
                পেমেন্ট ও ভেরিফিকেশন তথ্য:
              </p>
              <p>সফটওয়্যার অ্যাক্টিভেশনের জন্য যোগাযোগ করুন:</p>
              <p className="font-bold text-sm text-emerald-950 mt-1">
                বিকাশ (Personal): 01715047342
              </p>
              <p>প্রধান পরিচালক: MD Muhi Uddin</p>
            </div>

            <button
              onClick={onBack}
              className="w-full py-3 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-sm shadow-sm"
            >
              লগইন পেজে ফিরে যান
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Activation Notice Card */}
            <div className="bg-[#0A2E2B] text-white p-4 rounded-2xl shadow-sm border border-emerald-800">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-sm mb-1">
                <ShieldCheck className="w-4 h-4" />
                মাদ্রাসা ম্যানেজমেন্ট সফটওয়্যার
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                আপনার মাদ্রাসার সকল ছাত্রছাত্রী, শিক্ষক, দৈনিক সবক ও ফি কালেকশন ডিজিটালি পরিচালনা করতে নিচের ফর্মটি পূরণ করুন।
              </p>
              <div className="mt-2 text-xs font-semibold text-amber-200 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5" />
                বিকাশ ও হেল্পলাইন: 01715047342
              </div>
            </div>

            {/* Registration Form */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
              <h3 className="font-bold text-base text-slate-900 mb-4 flex items-center gap-2">
                <Building className="w-5 h-5 text-emerald-800" />
                মাদ্রাসার বিবরণী
              </h3>

              <form onSubmit={handleSubmit} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    মাদ্রাসার নাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={madrasaName}
                    onChange={(e) => setMadrasaName(e.target.value)}
                    placeholder="মাদ্রাসার পূর্ণ নাম লিখুন"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    মাদ্রাসার পূর্ণ ঠিকানা
                  </label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="গ্রাম, ডাকঘর, উপজেলা, জেলা"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    মুহতামিম / পরিচালকের নাম
                  </label>
                  <input
                    type="text"
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    placeholder="পরিচালকের নাম"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    মোবাইল নম্বর (লগইন আইডি) *
                  </label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ইমেইল এড্রেস
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="info@madrasa.org"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    পাসওয়ার্ড *
                  </label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="পাসওয়ার্ড দিন"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-1 focus:ring-emerald-700 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 px-4 rounded-xl font-bold text-white bg-[#2E7D32] hover:bg-emerald-800 transition-colors shadow-sm text-sm mt-3"
                >
                  রেজিস্ট্রেশন সম্পন্ন করুন
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
