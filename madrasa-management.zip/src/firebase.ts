import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth, signInAnonymously } from 'firebase/auth';

// Firebase configuration from project's google-services.json
export const firebaseConfig = {
  apiKey: "AIzaSyBZ0Jb9LxaASmDJCcYzxqwMabKbD72EuaI",
  authDomain: "madrasa-management-86fe0.firebaseapp.com",
  databaseURL: "https://madrasa-management-86fe0-default-rtdb.firebaseio.com",
  projectId: "madrasa-management-86fe0",
  storageBucket: "madrasa-management-86fe0.firebasestorage.app",
  messagingSenderId: "174418601382",
  appId: "1:174418601382:android:d5eba45c85c681cba41b67"
};

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let auth: Auth | null = null;

try {
  if (!getApps().length) {
    app = initializeApp(firebaseConfig);
  } else {
    app = getApps()[0];
  }
  db = getFirestore(app);
  auth = getAuth(app);
  if (auth) {
    signInAnonymously(auth).catch((err) => {
      // Gracefully handle if anonymous auth is not enabled on project
      console.warn("Firebase auth note:", err?.code || err?.message);
    });
  }
} catch (error) {
  console.warn("Firebase initialization warning (falling back to local resilient store):", error);
}

export { app, db, auth };
