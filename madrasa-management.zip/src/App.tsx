import React, { useState, useEffect } from 'react';
import { repository } from './services/repository';
import { ScreenType, UserAccount } from './types';
import { SplashScreen } from './screens/SplashScreen';
import { LoginScreen } from './screens/LoginScreen';
import { HomeScreen } from './screens/HomeScreen';
import { DailySobokScreen } from './screens/DailySobokScreen';
import { StudentTableScreen } from './screens/StudentTableScreen';
import { StudentHistoryScreen } from './screens/StudentHistoryScreen';
import { RoutineScreen } from './screens/RoutineScreen';
import { RegistrationRequestsScreen } from './screens/RegistrationRequestsScreen';
import { TeacherScreen } from './screens/TeacherScreen';
import { AttendanceScreen } from './screens/AttendanceScreen';
import { FeeScreen } from './screens/FeeScreen';
import { ExamScreen } from './screens/ExamScreen';
import { NoticeScreen } from './screens/NoticeScreen';
import { PoraProgressScreen } from './screens/PoraProgressScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { AdminManagementScreen } from './screens/AdminManagementScreen';
import { OtherMadrasaRegScreen } from './screens/OtherMadrasaRegScreen';
import { OtherMadrasaApprovalsScreen } from './screens/OtherMadrasaApprovalsScreen';

export default function App() {
  const [, setTick] = useState(0);

  // Subscribe to repository updates
  useEffect(() => {
    return repository.subscribe(() => setTick((t) => t + 1));
  }, []);

  const [currentScreen, setCurrentScreen] = useState<ScreenType>('splash');
  const [screenStack, setScreenStack] = useState<ScreenType[]>([]);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [isAppLockEnabled, setIsAppLockEnabled] = useState(false);

  // Load session from localStorage on start
  useEffect(() => {
    try {
      const saved = localStorage.getItem('madrasa_active_user');
      if (saved) {
        setCurrentUser(JSON.parse(saved));
      }
      const lock = localStorage.getItem('madrasa_app_lock');
      if (lock) {
        setIsAppLockEnabled(JSON.parse(lock));
      }
    } catch (e) {
      console.warn(e);
    }
  }, []);

  const navigateTo = (screen: ScreenType) => {
    if (currentScreen !== 'splash' && currentScreen !== screen) {
      setScreenStack((prev) => [...prev, currentScreen]);
    }
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateBack = () => {
    if (screenStack.length > 0) {
      const prev = screenStack[screenStack.length - 1];
      setScreenStack((s) => s.slice(0, -1));
      setCurrentScreen(prev);
    } else if (currentScreen !== 'home' && currentUser) {
      setCurrentScreen('home');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogin = (id: string, pass: string) => {
    setLoginError(null);
    const res = repository.login(id, pass);
    if (res.user) {
      setCurrentUser(res.user);
      localStorage.setItem('madrasa_active_user', JSON.stringify(res.user));
      setScreenStack([]);
      setCurrentScreen('home');
    } else {
      setLoginError(res.error || 'ভুল মোবাইল নম্বর বা পাসওয়ার্ড! সঠিক তথ্য দিন।');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('madrasa_active_user');
    setScreenStack([]);
    setCurrentScreen('login');
  };

  // Helper flags
  const isMainAdmin = currentUser?.isMain === true;
  const isAdmin = currentUser?.role === 'main' || currentUser?.role === 'sub';
  const isTeacher = currentUser?.role === 'teacher';
  const isGuardian = currentUser?.role === 'guardian';

  // Statistics
  const allThree = ['সবক', 'সাত সবক', 'আম্মোক্তা'];
  const todaySobokList = repository.getTodaySobokList();
  const allThreeCompletedCount = todaySobokList.filter((item) =>
    allThree.every((t) => item.completedSabaks.includes(t))
  ).length;
  const remainingSobokCount = Math.max(0, repository.students.length - allThreeCompletedCount);
  const pendingRequestsCount = repository.registrationRequests.filter(
    (r) => r.status === 'pending'
  ).length;

  return (
    <div className="min-h-screen bg-[#F4F7F5] selection:bg-emerald-900 selection:text-amber-200">
      {currentScreen === 'splash' && (
        <SplashScreen
          onFinish={() => {
            if (currentUser) {
              setCurrentScreen('home');
            } else {
              setCurrentScreen('login');
            }
          }}
        />
      )}

      {currentScreen === 'login' && (
        <LoginScreen
          onLogin={handleLogin}
          onSubmitRegistration={(req) => repository.submitRegistrationRequest(req)}
          errorMessage={loginError}
        />
      )}

      {currentScreen === 'otherMadrasaReg' && (
        <OtherMadrasaRegScreen
          onBack={() => navigateTo('login')}
          onSubmit={(reg) => repository.registerOtherMadrasa(reg)}
        />
      )}

      {currentScreen === 'home' && (
        <HomeScreen
          students={repository.students}
          teachers={repository.teachers}
          remainingSobokCount={remainingSobokCount}
          totalStudents={repository.students.length}
          pendingRequestsCount={pendingRequestsCount}
          latestNotice={repository.notices[0]}
          syncStatusText={repository.syncStatus}
          isSyncing={repository.isSyncing}
          onNavigate={(screen) => navigateTo(screen)}
        />
      )}

      {currentScreen === 'dailySobok' && (
        <DailySobokScreen
          sobokList={todaySobokList}
          currentUser={currentUser}
          onMarkCompleted={(itemId, type, para, page, teacher) => {
            repository.markSingleSabakCompleted(itemId, type, para, page, teacher);
          }}
          onStudentClick={(studentId) => {
            setSelectedStudentId(studentId);
            navigateTo('studentHistory');
          }}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'studentTable' && (
        <StudentTableScreen
          students={repository.students}
          isAdmin={isAdmin}
          onAddStudent={(s) => repository.addStudent(s)}
          onDeleteStudent={(id) => repository.deleteStudent(id)}
          onStudentClick={(studentId) => {
            setSelectedStudentId(studentId);
            navigateTo('studentHistory');
          }}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'studentHistory' && (
        <StudentHistoryScreen
          student={repository.students.find((s) => s.id === selectedStudentId)}
          historyList={repository.sabakHistory.filter((h) => h.studentId === selectedStudentId)}
          isAdmin={isAdmin}
          onDeleteHistoryItem={(id) => repository.deleteSabakHistoryRecord(id)}
          onBack={navigateBack}
        />
      )}

      {currentScreen === 'routine' && (
        <RoutineScreen
          classRoutines={repository.classRoutines}
          kajerRoutines={repository.kajerRoutines}
          isAdmin={isAdmin}
          isTeacher={isTeacher}
          isGuardian={isGuardian}
          onAddClassRoutine={(item) => repository.addClassRoutine(item)}
          onDeleteClassRoutine={(id) => repository.deleteClassRoutine(id)}
          onAddKajerRoutine={(item) => repository.addKajerRoutine(item)}
          onUpdateKajerStatus={(id, st) => repository.updateKajerRoutineStatus(id, st)}
          onDeleteKajerRoutine={(id) => repository.deleteKajerRoutine(id)}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'registrationRequests' && (
        <RegistrationRequestsScreen
          requests={repository.registrationRequests}
          onApprove={(id) => repository.approveRegistrationRequest(id)}
          onReject={(id) => repository.rejectRegistrationRequest(id)}
          onBack={navigateBack}
        />
      )}

      {currentScreen === 'teacherList' && (
        <TeacherScreen
          teachers={repository.teachers}
          isAdmin={isAdmin}
          onAddTeacher={(t, pass) => repository.addTeacher(t, pass)}
          onDeleteTeacher={(id) => repository.deleteTeacher(id)}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'attendance' && (
        <AttendanceScreen
          students={repository.students}
          attendanceList={repository.attendanceList}
          onMarkAttendance={(student, date, status) => {
            repository.markAttendance(student, date, status);
          }}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'fee' && (
        <FeeScreen
          feeList={repository.feeList}
          students={repository.students}
          isAdmin={isAdmin}
          onAddFeeRecord={(fee) => repository.addFeeRecord(fee)}
          onMarkFeePaid={(id, amount) => repository.markFeePaid(id, amount)}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'exam' && (
        <ExamScreen
          examResults={repository.examResults}
          students={repository.students}
          isAdmin={isAdmin}
          onAddResult={(res) => repository.addExamResult(res)}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'notice' && (
        <NoticeScreen
          notices={repository.notices}
          isAdmin={isAdmin}
          onAddNotice={(n) => repository.addNotice(n)}
          onDeleteNotice={(id) => repository.deleteNotice(id)}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'poraProgress' && (
        <PoraProgressScreen
          progressList={repository.poraProgressList}
          students={repository.students}
          currentUser={currentUser}
          onAddProgress={(item) => repository.addPoraProgress(item)}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'settings' && (
        <SettingsScreen
          currentUser={currentUser}
          isAppLockEnabled={isAppLockEnabled}
          onToggleAppLock={(enabled) => {
            setIsAppLockEnabled(enabled);
            localStorage.setItem('madrasa_app_lock', JSON.stringify(enabled));
          }}
          onChangePassword={(newPass) => {
            if (currentUser) {
              repository.savePasswordLocally(currentUser.email, newPass);
              repository.savePasswordLocally(currentUser.phone, newPass);
            }
          }}
          onNavigate={(screen) => navigateTo(screen)}
          onLogout={handleLogout}
          onBack={() => navigateTo('home')}
        />
      )}

      {currentScreen === 'adminManagement' && (
        <AdminManagementScreen
          users={repository.users}
          currentUser={currentUser}
          onAddSecondAdmin={(name, phone, pass) => {
            return repository.addSecondAdmin(
              name,
              phone,
              pass,
              currentUser?.name || 'MD Muhi Uddin'
            );
          }}
          onDeleteSecondAdmin={(id) => repository.deleteSecondAdmin(id)}
          onBack={() => navigateTo('settings')}
        />
      )}

      {currentScreen === 'otherMadrasaApprovals' && (
        <OtherMadrasaApprovalsScreen
          registrations={repository.registrations}
          onUpdateStatus={(id, status) => repository.updateMadrasaStatus(id, status)}
          onBack={() => navigateTo('settings')}
        />
      )}
    </div>
  );
}
