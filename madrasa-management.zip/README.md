# Madrasa Management (মাদ্রাসা ম্যানেজমেন্ট) - Flutter Project

অনলাইন মাদ্রাসা ম্যানেজমেন্ট সিস্টেম - হযরত শাহজালাল (রহঃ) লতিফিয়া কচুরকান্দি হাফিজিয়া মাদ্রাসা।

## Features & Implementation Highlights

1. **Logo & App Icon (Issue 1 & 3)**:
   - Original High-Resolution Logo placed at `assets/logo.png`, `assets/images/logo.png`, and `assets/images/login_logo.png`.
   - Android Launcher Icon generated at `android/app/src/main/res/mipmap/launcher_icon.png` and all mipmap density folders (`mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`).
   - Circular golden frame (Border #D4AF37, width 3) applied uniformly across Splash, Login, and Custom App Bar.

2. **Login & Registration Flow (Issue 2, 5 & 6)**:
   - **Main Admin Credentials**:
     - Email / Phone: `muhiuddin.bd.mb@gmail.com` or `01715047342`
     - Password: `MS723926MS`
   - **Registration Flow**:
     - Fields: Full Name (বাংলায়), Mobile Number, Email, Password, Confirm Password.
     - Role Selection: `Admin (অন্য মাদ্রাসা এডমিন / Admin for other madrasa)`, `Teacher (শিক্ষক)`, `Guardian (অভিভাবক)`.
     - **Conditional Fees**: Fee notice is displayed **only for Admin role** (১ম রেজিস্ট্রেশন ৫০০ টাকা + মাসিক ২০০ টাকা). No fees shown for Teacher / Guardian.
     - Submitting saves directly to Firestore collection `pending_requests` with status `pending`.
     - SnackBar notification: `"আপনার রেজিস্ট্রেশন রিকোয়েস্ট এডমিনের কাছে গেছে। এপ্রুভ হলে লগইন করতে পারবেন।"`
   - **Admin Approval Screen (`lib/screens/admin_approval_screen.dart`)**:
     - Realtime StreamBuilder on `pending_requests` where status is `pending`.
     - Displays applicant details, mobile, selected role, and fee status.
     - Approve button: Creates the user in `users` collection with `approved: true` and credentials, then updates pending request status to `approved`.
     - Reject button: Updates status to `rejected`.
   - **Login Security**:
     - Pending requests are prevented from logging in with `"Not approved yet (আপনার রেজিস্ট্রেশন রিকোয়েস্ট এখনও এপ্রুভ হয়নি)"`.
     - Unapproved users are blocked until approved by the Main Admin.

3. **Android Build & Dex Configuration (Issue 4)**:
   - Package Name & Application ID: `com.madrasa.management2`
   - Google Services configured via `android/app/google-services.json`
   - AndroidManifest configured with `@mipmap/launcher_icon`, `@string/app_name`, and `@style/Theme.MyApplication`
   - Kotlin MainActivity implemented at `android/app/src/main/kotlin/com/madrasa/management2/MainActivity.kt`
   - Gradle properties and dependencies updated for modern Flutter build without legacy compatibility warnings or "no class files to dex" errors.

## Building and Running the App

### 1. Get Dependencies
```bash
flutter pub get
```

### 2. Build Release APK
```bash
flutter build apk --release
```
The compiled APK will be generated at:
`build/app/outputs/flutter-apk/app-release.apk`

### 3. Run in Debug Mode
```bash
flutter run
```
