package com.madrasa.management2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
