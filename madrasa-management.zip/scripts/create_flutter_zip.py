import os
import zipfile

def create_flutter_zip():
    zip_filename = "madrasa_management_flutter.zip"
    public_zip = os.path.join("public", zip_filename)
    
    # Files and folders to include in the Flutter project
    include_paths = [
        "pubspec.yaml",
        "README.md",
        "lib",
        "assets",
        "android",
    ]
    
    # Exclude patterns
    exclude_dirs = {
        ".git", ".gradle", "build", ".dart_tool", "node_modules",
        "dist", ".vite", "__pycache__"
    }
    exclude_extensions = {".class", ".pyc", ".lock"}

    print(f"Creating {zip_filename}...")
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zf:
        for item in include_paths:
            if os.path.isfile(item):
                zf.write(item, item)
                print(f"Added file: {item}")
            elif os.path.isdir(item):
                for root, dirs, files in os.walk(item):
                    # Filter out excluded directories in-place
                    dirs[:] = [d for d in dirs if d not in exclude_dirs]
                    
                    for f in files:
                        ext = os.path.splitext(f)[1]
                        if ext in exclude_extensions:
                            continue
                        full_path = os.path.join(root, f)
                        rel_path = os.path.relpath(full_path, ".")
                        zf.write(full_path, rel_path)
    
    # Also copy to public directory for direct download in browser
    os.makedirs("public", exist_ok=True)
    with open(zip_filename, "rb") as src, open(public_zip, "wb") as dst:
        dst.write(src.read())

    print(f"Successfully generated {zip_filename} ({os.path.getsize(zip_filename)} bytes)")
    print(f"Copied to {public_zip}")

if __name__ == "__main__":
    create_flutter_zip()
