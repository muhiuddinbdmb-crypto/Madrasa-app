const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// Create a PNG buffer from raw RGBA pixel data
function createPng(width, height, getPixel) {
  const rowBytes = width * 4;
  const rawData = Buffer.alloc(height * (rowBytes + 1));
  
  let offset = 0;
  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter byte: None
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = getPixel(x, y, width, height);
      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  const deflated = zlib.deflateSync(rawData);

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // CRC32 helper
  function crc32(buf) {
    let crc = 0 ^ (-1);
    for (let i = 0; i < buf.length; i++) {
      crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
    }
    return (crc ^ (-1)) >>> 0;
  }
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = ((c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1));
    }
    table[i] = c;
  }

  function makeChunk(typeStr, dataBuf) {
    const typeBuf = Buffer.from(typeStr, 'ascii');
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32BE(dataBuf.length, 0);

    const crcBuf = Buffer.alloc(4);
    const combined = Buffer.concat([typeBuf, dataBuf]);
    crcBuf.writeUInt32BE(crc32(combined), 0);

    return Buffer.concat([lenBuf, combined, crcBuf]);
  }

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // 8 bits per channel
  ihdrData[9] = 6; // RGBA
  ihdrData[10] = 0; // Deflate
  ihdrData[11] = 0; // Filter
  ihdrData[12] = 0; // Interlace
  const ihdrChunk = makeChunk('IHDR', ihdrData);

  // IDAT
  const idatChunk = makeChunk('IDAT', deflated);

  // IEND
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

// Generate circular emblem matching Image 1
const W = 300;
const H = 300;
const cx = W / 2;
const cy = H / 2;

const pngBuf = createPng(W, H, (x, y) => {
  const dx = x - cx;
  const dy = y - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);

  if (dist > 146) return [0, 0, 0, 0]; // Transparent outside

  // Outer gold rim
  if (dist > 142) return [212, 175, 55, 255]; // #D4AF37

  // Thin separator
  if (dist > 139) return [255, 255, 255, 255];

  // Navy Blue Ring (108 to 139)
  if (dist > 108) {
    // Check if dot positions
    const angle = Math.atan2(dy, dx);
    const isLeftDot = Math.abs(angle - Math.PI) < 0.1 || Math.abs(angle + Math.PI) < 0.1;
    const isRightDot = Math.abs(angle) < 0.1;
    if ((isLeftDot || isRightDot) && dist > 120 && dist < 127) {
      return [212, 175, 55, 255]; // Gold dots
    }
    // Gradient dark navy blue
    return [10, 52, 100, 255]; // #0A3464
  }

  // Inner gold border
  if (dist > 105) return [212, 175, 55, 255];
  if (dist > 103) return [255, 255, 255, 255];

  // Center field
  // Mosque dome area in center
  if (dist < 103) {
    // Check Mihrab / green arched region
    if (y > 90 && y < 210 && Math.abs(dx) < 70) {
      // Dome
      if (y < 160 && dist < 45) {
        return [13, 75, 45, 255]; // Emerald Dome
      }
      // Rehal / Quran area
      if (y >= 140 && y <= 185 && Math.abs(dx) < 55) {
        if (Math.abs(dx) < 45 && y < 175) {
          // Quran pages (cream white)
          return [255, 255, 255, 255];
        }
        return [13, 59, 36, 255]; // Rehal stand
      }
      // Green niche
      return [45, 90, 39, 255];
    }

    // Torch on right (dx > 42 && dx < 58 && y > 110 && y < 190)
    if (dx > 40 && dx < 56 && y > 105 && y < 185) {
      if (y < 125) return [230, 81, 0, 255]; // Orange flame
      if (y < 135) return [212, 175, 55, 255]; // Gold cup
      return [10, 52, 100, 255]; // Blue handle
    }

    // Wreath at bottom
    if (y > 195 && y < 225 && Math.abs(dx) < 75 && Math.abs(dx) > 20) {
      return [46, 125, 50, 255]; // Green leaves
    }

    // Cream background
    return [252, 249, 240, 255];
  }

  return [255, 255, 255, 255];
});

// Write to all target locations
const targets = [
  'assets/logo.png',
  'assets/images/logo.png',
  'public/logo.png',
  'public/assets/logo.png',
  'public/assets/images/logo.png',
  'src/assets/logo.png',
  'android/app/src/main/res/mipmap-mdpi/launcher_icon.png',
  'android/app/src/main/res/mipmap-hdpi/launcher_icon.png',
  'android/app/src/main/res/mipmap-xhdpi/launcher_icon.png',
  'android/app/src/main/res/mipmap-xxhdpi/launcher_icon.png',
  'android/app/src/main/res/mipmap-xxxhdpi/launcher_icon.png'
];

targets.forEach((relPath) => {
  const fullPath = path.resolve(relPath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, pngBuf);
  console.log(`Saved ${fullPath} (${pngBuf.length} bytes)`);
});
